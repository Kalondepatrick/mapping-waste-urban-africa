# Waste Review QGIS Plugin

**Authors:** Patrick Ken Kalonde and OpenAI  
**Version:** 0.3.0

A native QGIS implementation of the three-stage waste-prediction review workflow originally developed as a Shiny application.

## Dedicated review canvas

Version 0.3.0 replaces the narrow map-driven review interface with a dedicated **Waste Prediction Review** window modelled on the original Shiny app:

- scrollable review controls on the left;
- a large PNG review canvas on the right;
- the original prepared 50 m review images from `www/chips`;
- red prediction outlines already contained in the prepared PNGs;
- a transparent yellow locator box for Stage 2 and Stage 3;
- `Reviewed x / N` progress above the image;
- keyboard shortcuts `1`–`4` and `S`;
- image pan, mouse-wheel zoom, **Fit image**, and **100%** controls;
- optional **Show current item on QGIS map** for spatial context;
- Stage-3 geometry editing still uses the normal QGIS map/editing tools.

For existing Shiny projects, selecting `review_log.sqlite` automatically looks for:

- `data/review_grid.gpkg`
- `data/object_chip_map.csv`
- `data/chips.csv`
- `data/second_review_candidates.csv`
- `data/third_review_candidates.csv`
- `www/chips/`
- `../../outputs/waste_piles.shp`
- `exports/`

When the prepared Stage-2 or Stage-3 candidate CSV exists, the plugin reuses its `base_image_file`, `display_chip_id`, and percentage bounding-box coordinates. This preserves the same image/target presentation used in the Shiny review. If those prepared files do not exist, the plugin calculates the display cell and compact yellow bounding box from the prediction and review-grid geometry.

## Reopen an existing annotated project

Open **Vector → Waste Review**, then click **Load existing project…**.

Select an existing `review_log.sqlite`. The plugin reads all existing Stage 1, Stage 2 and Stage 3 annotations and continues from the saved progress. Existing decisions, notes, reviewer names, history, and claims use the original Shiny table structure and are not reset.

After the project opens successfully, its paths—including the review-canvas `chips.csv` and PNG directory—are stored in the `project_metadata` table inside the same SQLite database. The same project can then be reopened from **Recent projects**.

## Prediction layers without `candidate_id`

Legacy `waste_piles.shp` files do not need to be edited manually. If the prediction layer lacks `candidate_id`, the plugin reconstructs IDs using the same row-order rule used by the Shiny workflow and validates them against the unique IDs in `object_chip_map.csv`.

A persistent working GeoPackage called `waste_predictions_with_candidate_id.gpkg` is created in the export folder. The original shapefile is left unchanged. If feature counts or candidate IDs cannot be reconciled safely, the plugin stops rather than guessing.

## Review workflow

### Stage 1 — location review

1. Waste
2. Not waste
3. Waste + false positives
4. Not sure

### Stage 2 — ambiguous object review

1. Waste
2. Not waste
3. Not sure

Only predictions at or above the configured minimum area (default **0.25 m²**) are manually reviewed at Stage 2.

### Stage 3 — final positive audit

1. Keep
2. Delete
3. Needs edit
4. Not sure

For **Needs edit**, add the working prediction layer to the QGIS project and use **Edit current Stage-3 geometry** to activate normal QGIS geometry editing.

## QGIS 3.34 safety

The plugin does **not** automatically call `QgsProject.addMapLayer()` during startup. This avoids the native `layerWasAdded` access violation observed with QGIS 3.34.7 on Windows. Review layers remain private unless the same source is already loaded by the user.

## Compatibility target

QGIS **3.34.7-Prizren LTR**, Python 3.12, Qt 5.15.13. Minimum declared QGIS version remains 3.28.
