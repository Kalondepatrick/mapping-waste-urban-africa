from qgis.PyQt.QtWidgets import QAction, QMessageBox
from qgis.core import Qgis

from .config_dialog import ConfigDialog
from .database import ReviewDatabase
from .review_engine import ReviewEngine
from .review_window import WasteReviewWindow


class WasteReviewPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.action = None
        self.window = None

    def initGui(self):
        self.action = QAction("Waste Review", self.iface.mainWindow())
        self.action.setToolTip("Open the three-stage waste prediction review workflow")
        self.action.triggered.connect(self.run)
        self.iface.addPluginToVectorMenu("Waste Review", self.action)
        self.iface.addToolBarIcon(self.action)

    def unload(self):
        if self.window:
            self.window.close()
            self.window = None
        if self.action:
            self.iface.removePluginVectorMenu("Waste Review", self.action)
            self.iface.removeToolBarIcon(self.action)
            self.action = None

    def run(self):
        if self.window:
            self.window.show()
            self.window.raise_()
            self.window.activateWindow()
            return

        dlg = ConfigDialog(self.iface.mainWindow())
        if not dlg.exec_():
            return
        cfg = dlg.config()
        try:
            db = ReviewDatabase(cfg["database"])
            engine = ReviewEngine(cfg, db)
            if getattr(engine, "generated_prediction_copy", None):
                self.iface.messageBar().pushMessage(
                    "Waste Review",
                    "The prediction layer had no candidate_id field. A working GeoPackage "
                    "was created with IDs matched to object_chip_map.csv: "
                    + engine.generated_prediction_copy,
                    level=Qgis.MessageLevel.Info,
                    duration=12,
                )

            # Save the paths after successful loading. This includes the Shiny
            # chip-image paths used by the dedicated review canvas.
            db.save_project_config(cfg)

            self.window = WasteReviewWindow(
                self.iface, engine, db, cfg, self.iface.mainWindow()
            )
            self.window.destroyed.connect(self._window_destroyed)
            self.window.show()
            self.window.raise_()
            self.window.activateWindow()
        except Exception as exc:
            QMessageBox.critical(self.iface.mainWindow(), "Waste Review", str(exc))
            self.window = None

    def _window_destroyed(self, *args):
        self.window = None
