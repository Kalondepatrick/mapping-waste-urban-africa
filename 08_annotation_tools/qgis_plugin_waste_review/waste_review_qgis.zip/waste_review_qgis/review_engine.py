import csv
import os
from collections import defaultdict

from qgis.core import (
    QgsCoordinateReferenceSystem,
    QgsDistanceArea,
    QgsFeatureRequest,
    QgsGeometry,
    QgsProject,
    QgsVectorLayer,
)


class ReviewEngine:
    def __init__(self, config, db):
        self.config = config
        self.db = db
        self.grid_layer = None
        self.pred_layer = None
        self.object_chip_map = defaultdict(list)
        self.chip_to_candidates = defaultdict(list)
        self.grid_feature_by_chip = {}
        self.pred_feature_by_candidate = {}
        self.pred_area_m2 = {}
        self.stage1_status = {}
        self.stage1_reason = {}
        self.representative_chip = {}
        self.stage2_ids = []
        self.stage3_ids = []
        self.review_source = {}
        self.distance_area = QgsDistanceArea()
        self.load()

    def _vector_layer(self, path, name):
        layer = QgsVectorLayer(path, name, "ogr")
        if not layer.isValid():
            raise RuntimeError(f"Could not load {name}: {path}")
        return layer

    def load(self):
        self.grid_layer = self._vector_layer(self.config["review_grid"], "Waste review grid")
        self.pred_layer = self._vector_layer(self.config["predictions"], "Waste predictions")

        if self.grid_layer.fields().indexFromName("chip_id") < 0:
            raise RuntimeError("Review grid must contain a chip_id field.")

        if self.pred_layer.fields().indexFromName("candidate_id") < 0:
            raise RuntimeError(
                "Prediction layer must contain a candidate_id field. Add the same candidate IDs used by object_chip_map.csv."
            )

        self.distance_area.setSourceCrs(
            self.pred_layer.crs(), QgsProject.instance().transformContext()
        )
        ellipsoid = QgsProject.instance().ellipsoid()
        if ellipsoid:
            self.distance_area.setEllipsoid(ellipsoid)

        self.grid_feature_by_chip = {
            str(f["chip_id"]): f for f in self.grid_layer.getFeatures()
        }
        self.refresh_prediction_cache()

        with open(self.config["object_chip_map"], newline="", encoding="utf-8-sig") as fh:
            reader = csv.DictReader(fh)
            need = {"candidate_id", "chip_id"}
            if not need.issubset(set(reader.fieldnames or [])):
                raise RuntimeError("object_chip_map.csv must contain candidate_id and chip_id.")
            for row in reader:
                cid = str(row["candidate_id"])
                chip = str(row["chip_id"])
                if chip not in self.object_chip_map[cid]:
                    self.object_chip_map[cid].append(chip)
                if cid not in self.chip_to_candidates[chip]:
                    self.chip_to_candidates[chip].append(cid)

        self.refresh_prediction_cache()
        self.refresh_stage1_status()

    def refresh_prediction_cache(self):
        self.pred_feature_by_candidate = {
            str(f["candidate_id"]): f for f in self.pred_layer.getFeatures()
        }
        self.pred_area_m2 = {}
        for cid, feat in self.pred_feature_by_candidate.items():
            geom = feat.geometry()
            try:
                area = float(self.distance_area.measureArea(geom))
            except Exception:
                area = float(geom.area())
            self.pred_area_m2[cid] = area

    @property
    def min_area(self):
        return float(self.config.get("min_area_m2", 0.25))

    def stage1_items(self):
        return list(self.grid_feature_by_chip.keys())

    @staticmethod
    def classify_stage1_statuses(statuses):
        x = sorted(set(str(v) for v in statuses))
        if "unreviewed" in x:
            return "pending"
        if any(v in {"mixed", "not_sure"} for v in x):
            return "second_review"
        if x and all(v == "waste" for v in x):
            return "retained"
        if x and all(v == "not_waste" for v in x):
            return "rejected"
        return "second_review"

    def refresh_stage1_status(self):
        s1 = self.db.current(1)
        self.stage1_status = {}
        self.stage1_reason = {}
        self.representative_chip = {}

        for cid in self.pred_feature_by_candidate:
            chips = self.object_chip_map.get(cid, [])
            statuses = [s1.get(ch, {"label": "unreviewed"})["label"] for ch in chips]
            if not statuses:
                self.stage1_status[cid] = "pending"
                self.stage1_reason[cid] = "not_mapped_to_review_grid"
                self.representative_chip[cid] = None
                continue
            self.stage1_status[cid] = self.classify_stage1_statuses(statuses)
            self.stage1_reason[cid] = " + ".join(sorted(set(statuses)))
            ambiguous = [
                ch for ch in chips if s1.get(ch, {"label": "unreviewed"})["label"] in {"mixed", "not_sure"}
            ]
            self.representative_chip[cid] = ambiguous[0] if ambiguous else chips[0]

    def prepare_stage2(self):
        s1 = self.db.current(1)
        missing = [ch for ch in self.stage1_items() if ch not in s1]
        if missing:
            raise RuntimeError(f"Stage 1 is not complete. {len(missing)} location(s) remain.")
        self.refresh_stage1_status()
        ids = [
            cid for cid in self.pred_feature_by_candidate
            if self.stage1_status.get(cid) == "second_review"
            and self.pred_area_m2.get(cid, 0) >= self.min_area
            and self.representative_chip.get(cid)
        ]
        ids.sort(key=self._candidate_sort_key)
        self.stage2_ids = ids
        return ids

    def prepare_stage3(self):
        if not self.stage2_ids:
            self.prepare_stage2()
        s2 = self.db.current(2)
        unreviewed = [cid for cid in self.stage2_ids if cid not in s2]
        unsure = [cid for cid in self.stage2_ids if s2.get(cid, {}).get("label") == "not_sure"]
        if unreviewed or unsure:
            raise RuntimeError(
                f"Stage 2 must be fully resolved before Stage 3. {len(unreviewed)} unreviewed and {len(unsure)} marked Not sure."
            )

        s1_positive = [
            cid for cid in self.pred_feature_by_candidate
            if self.pred_area_m2.get(cid, 0) >= self.min_area
            and self.stage1_status.get(cid) == "retained"
        ]
        s2_positive = [cid for cid in self.stage2_ids if s2[cid]["label"] == "waste"]
        ids = []
        self.review_source = {}
        for cid in s1_positive:
            if cid not in ids:
                ids.append(cid)
                self.review_source[cid] = "stage1"
        for cid in s2_positive:
            if cid not in ids:
                ids.append(cid)
                self.review_source[cid] = "stage2"
        ids.sort(key=self._candidate_sort_key)
        self.stage3_ids = ids
        return ids

    @staticmethod
    def _candidate_sort_key(cid):
        try:
            return (0, int(cid))
        except Exception:
            return (1, str(cid))

    def feature_for(self, stage, item_id):
        if int(stage) == 1:
            return self.grid_feature_by_chip.get(str(item_id)), self.grid_layer
        return self.pred_feature_by_candidate.get(str(item_id)), self.pred_layer

    def active_ids(self, stage):
        if int(stage) == 1:
            return self.stage1_items()
        if int(stage) == 2:
            if not self.stage2_ids:
                return self.prepare_stage2()
            return self.stage2_ids
        if not self.stage3_ids:
            return self.prepare_stage3()
        return self.stage3_ids

    def next_unreviewed(self, stage, after=None, include_not_sure=False):
        ids = self.active_ids(stage)
        current = self.db.current(stage)
        start = 0
        if after is not None and str(after) in ids:
            start = ids.index(str(after)) + 1
        order = ids[start:] + ids[:start]
        for item_id in order:
            row = current.get(str(item_id))
            if row is None or (include_not_sure and row["label"] == "not_sure"):
                return str(item_id)
        return None

    def stage_progress(self, stage):
        ids = self.active_ids(stage)
        current = self.db.current(stage)
        reviewed = sum(1 for x in ids if str(x) in current)
        return reviewed, len(ids), self.db.counts(stage, ids)
