from qgis.PyQt.QtCore import Qt, QTimer
from qgis.PyQt.QtGui import QKeySequence
from qgis.PyQt.QtWidgets import (
    QComboBox, QDockWidget, QGridLayout, QGroupBox, QHBoxLayout, QLabel,
    QLineEdit, QMessageBox, QProgressBar, QPushButton, QShortcut,
    QTextEdit, QVBoxLayout, QWidget
)
from qgis.core import QgsHighlight, QgsProject

from .export_engine import ExportEngine


class WasteReviewDock(QDockWidget):
    def __init__(self, iface, engine, db, config, parent=None):
        super().__init__("Waste Review", parent)
        self.iface = iface
        self.engine = engine
        self.db = db
        self.config = config
        self.reviewer = config["reviewer"]
        self.stage = 1
        self.current_id = None
        self.highlight = None
        self.skipped = {1: set(), 2: set(), 3: set()}
        self.shortcuts = []

        self._build_ui()
        self._register_shortcuts()
        self._ensure_layers_visible()
        self.refresh_stage(1)

        self.heartbeat = QTimer(self)
        self.heartbeat.setInterval(120000)
        self.heartbeat.timeout.connect(self.touch_claim)
        self.heartbeat.start()

    def _build_ui(self):
        body = QWidget()
        main = QVBoxLayout(body)
        main.setContentsMargins(8, 8, 8, 8)

        top = QHBoxLayout()
        top.addWidget(QLabel("Reviewer:"))
        reviewer = QLineEdit(self.reviewer)
        reviewer.setReadOnly(True)
        top.addWidget(reviewer, 1)
        main.addLayout(top)

        self.stage_combo = QComboBox()
        self.stage_combo.addItem("Stage 1 — 50 m location review", 1)
        self.stage_combo.addItem("Stage 2 — object review", 2)
        self.stage_combo.addItem("Stage 3 — final positive audit", 3)
        self.stage_combo.currentIndexChanged.connect(self.on_stage_changed)
        main.addWidget(self.stage_combo)

        stage_tools = QHBoxLayout()
        self.prepare2 = QPushButton("Prepare / refresh Stage 2")
        self.prepare3 = QPushButton("Prepare / refresh Stage 3")
        self.prepare2.clicked.connect(self.prepare_stage2)
        self.prepare3.clicked.connect(self.prepare_stage3)
        stage_tools.addWidget(self.prepare2)
        stage_tools.addWidget(self.prepare3)
        main.addLayout(stage_tools)

        info = QGroupBox("Current review item")
        info_lay = QGridLayout(info)
        self.item_label = QLabel("—")
        self.item_label.setTextInteractionFlags(Qt.TextSelectableByMouse)
        self.area_label = QLabel("—")
        self.source_label = QLabel("—")
        info_lay.addWidget(QLabel("ID"), 0, 0)
        info_lay.addWidget(self.item_label, 0, 1)
        info_lay.addWidget(QLabel("Area"), 1, 0)
        info_lay.addWidget(self.area_label, 1, 1)
        info_lay.addWidget(QLabel("Source / status"), 2, 0)
        info_lay.addWidget(self.source_label, 2, 1)
        main.addWidget(info)

        self.progress_text = QLabel("0 / 0")
        self.progress = QProgressBar()
        self.progress.setRange(0, 100)
        main.addWidget(self.progress_text)
        main.addWidget(self.progress)

        self.class_box = QGroupBox("Classification")
        self.class_layout = QGridLayout(self.class_box)
        main.addWidget(self.class_box)

        self.notes = QTextEdit()
        self.notes.setPlaceholderText("Optional notes")
        self.notes.setMaximumHeight(90)
        main.addWidget(self.notes)

        nav = QHBoxLayout()
        self.prev_btn = QPushButton("◀ Previous")
        self.skip_btn = QPushButton("Skip (S)")
        self.next_btn = QPushButton("Next ▶")
        self.prev_btn.clicked.connect(self.previous_item)
        self.skip_btn.clicked.connect(self.skip_item)
        self.next_btn.clicked.connect(self.next_item)
        nav.addWidget(self.prev_btn)
        nav.addWidget(self.skip_btn)
        nav.addWidget(self.next_btn)
        main.addLayout(nav)

        self.edit_btn = QPushButton("Start geometry edit for current object")
        self.edit_btn.clicked.connect(self.start_geometry_edit)
        self.edit_btn.setVisible(False)
        main.addWidget(self.edit_btn)

        self.status = QLabel("")
        self.status.setWordWrap(True)
        main.addWidget(self.status)

        export = QPushButton("Export current results")
        export.clicked.connect(self.export_results)
        main.addWidget(export)
        main.addStretch(1)

        self.setWidget(body)
        self.rebuild_classification_buttons()

    def _ensure_layers_visible(self):
        project = QgsProject.instance()
        existing = {lyr.source(): lyr for lyr in project.mapLayers().values()}
        for layer in (self.engine.grid_layer, self.engine.pred_layer):
            if layer.source() not in existing:
                project.addMapLayer(layer)
            else:
                if layer == self.engine.grid_layer:
                    self.engine.grid_layer = existing[layer.source()]
                else:
                    self.engine.pred_layer = existing[layer.source()]
        # Keep the engine cache tied to the actual project prediction layer.
        self.engine.refresh_prediction_cache()
        self.engine.refresh_stage1_status()

    def _register_shortcuts(self):
        for key, handler in [
            ("1", lambda: self.classify_by_key(1)),
            ("2", lambda: self.classify_by_key(2)),
            ("3", lambda: self.classify_by_key(3)),
            ("4", lambda: self.classify_by_key(4)),
            ("S", self.skip_item),
        ]:
            sc = QShortcut(QKeySequence(key), self)
            sc.setContext(Qt.WidgetWithChildrenShortcut)
            sc.activated.connect(handler)
            self.shortcuts.append(sc)

    def rebuild_classification_buttons(self):
        while self.class_layout.count():
            item = self.class_layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()
        if self.stage == 1:
            spec = [(1, "Waste", "waste"), (2, "Not waste", "not_waste"),
                    (3, "Waste + false positives", "mixed"), (4, "Not sure", "not_sure")]
        elif self.stage == 2:
            spec = [(1, "Waste", "waste"), (2, "Not waste", "not_waste"), (3, "Not sure", "not_sure")]
        else:
            spec = [(1, "Keep", "keep"), (2, "Delete", "delete"),
                    (3, "Needs edit", "needs_edit"), (4, "Not sure", "not_sure")]
        self.key_labels = {}
        for i, (key, text, label) in enumerate(spec):
            btn = QPushButton(f"{key} — {text}")
            btn.clicked.connect(lambda checked=False, lab=label: self.save_label(lab))
            self.class_layout.addWidget(btn, i // 2, i % 2)
            self.key_labels[key] = label
        self.edit_btn.setVisible(self.stage == 3)

    def classify_by_key(self, key):
        label = getattr(self, "key_labels", {}).get(key)
        if label:
            self.save_label(label)

    def on_stage_changed(self):
        self.release_current_claim()
        self.stage = int(self.stage_combo.currentData())
        self.rebuild_classification_buttons()
        self.refresh_stage(self.stage)

    def prepare_stage2(self):
        try:
            ids = self.engine.prepare_stage2()
            self.status.setText(f"Stage 2 prepared: {len(ids):,} object(s).")
            self.stage_combo.setCurrentIndex(1)
        except Exception as e:
            QMessageBox.warning(self, "Stage 2", str(e))

    def prepare_stage3(self):
        try:
            ids = self.engine.prepare_stage3()
            self.status.setText(f"Stage 3 prepared: {len(ids):,} positive object(s).")
            self.stage_combo.setCurrentIndex(2)
        except Exception as e:
            QMessageBox.warning(self, "Stage 3", str(e))

    def refresh_stage(self, stage):
        try:
            ids = self.engine.active_ids(stage)
        except Exception as e:
            self.status.setText(str(e))
            self.clear_current()
            self.update_progress()
            return
        current = self.db.current(stage)
        target = None
        for item_id in ids:
            if str(item_id) not in current and str(item_id) not in self.skipped[stage]:
                target = str(item_id)
                break
        if target is None and ids:
            # Nothing unreviewed remains; show the first item for audit/correction.
            target = str(ids[0])
        if target:
            self.open_item(target)
        else:
            self.clear_current()
            self.status.setText(f"Stage {stage} has no review items.")
        self.update_progress()

    def open_item(self, item_id):
        self.release_current_claim()
        item_id = str(item_id)
        if not self.db.claim(self.stage, item_id, self.reviewer):
            nxt = self.engine.next_unreviewed(self.stage, after=item_id)
            if nxt and nxt != item_id:
                return self.open_item(nxt)
            self.status.setText("This item is open in another review session.")
            return
        self.current_id = item_id
        row = self.db.get(self.stage, item_id)
        self.notes.setPlainText(row.get("notes", "") if row else "")
        if self.stage in (2, 3):
            self.engine.refresh_prediction_cache()
        feat, layer = self.engine.feature_for(self.stage, item_id)
        if feat is None:
            self.status.setText(f"Feature {item_id} could not be found.")
            return
        self.item_label.setText(item_id)
        if self.stage == 1:
            self.area_label.setText("50 m review location")
            self.source_label.setText(row.get("label", "unreviewed") if row else "unreviewed")
        else:
            area = self.engine.pred_area_m2.get(item_id, 0.0)
            self.area_label.setText(f"{area:,.3f} m²")
            if self.stage == 2:
                self.source_label.setText(
                    f"Stage 1: {self.engine.stage1_status.get(item_id, '')} ({self.engine.stage1_reason.get(item_id, '')})"
                )
            else:
                self.source_label.setText(f"Entered from {self.engine.review_source.get(item_id, 'positive inventory')}")
        self.highlight_feature(feat, layer)
        self.zoom_to_feature(feat, layer)
        self.status.setText("Previously reviewed — change the label to correct it." if row else "Ready for review.")
        self.update_progress()

    def highlight_feature(self, feat, layer):
        if self.highlight:
            self.highlight.hide()
            self.highlight.deleteLater()
            self.highlight = None
        self.highlight = QgsHighlight(self.iface.mapCanvas(), feat.geometry(), layer)
        self.highlight.setWidth(4)
        self.highlight.setBuffer(1)
        self.highlight.show()

    def zoom_to_feature(self, feat, layer):
        canvas = self.iface.mapCanvas()
        extent = feat.geometry().boundingBox()
        if extent.isEmpty():
            return
        # Context: Stage 1 gets its cell plus a small margin; object review gets at least ~20 m around the target.
        if self.stage == 1:
            extent.scale(1.25)
        else:
            width = max(extent.width(), 20.0)
            height = max(extent.height(), 20.0)
            cx = extent.center().x()
            cy = extent.center().y()
            from qgis.core import QgsRectangle
            extent = QgsRectangle(cx - width, cy - height, cx + width, cy + height)
        canvas.setExtent(extent)
        canvas.refresh()
        layer.selectByIds([feat.id()])

    def save_label(self, label):
        if not self.current_id:
            return
        try:
            self.db.save(self.stage, self.current_id, label, self.reviewer, self.notes.toPlainText())
            if self.stage == 1:
                self.engine.refresh_stage1_status()
            if self.stage == 3 and label == "needs_edit":
                self.status.setText("Marked Needs edit. Use the geometry-edit button to correct the polygon, then reclassify it.")
            else:
                self.status.setText(f"Saved: {label}")
            previous = self.current_id
            self.update_progress()
            nxt = self.engine.next_unreviewed(self.stage, after=previous)
            if nxt:
                self.open_item(nxt)
            else:
                self.status.setText(f"Stage {self.stage}: no unreviewed items remain.")
        except Exception as e:
            QMessageBox.critical(self, "Waste Review", str(e))

    def next_item(self):
        ids = self.engine.active_ids(self.stage)
        if not ids:
            return
        if self.current_id in ids:
            idx = (ids.index(self.current_id) + 1) % len(ids)
        else:
            idx = 0
        self.open_item(ids[idx])

    def previous_item(self):
        ids = self.engine.active_ids(self.stage)
        if not ids:
            return
        if self.current_id in ids:
            idx = (ids.index(self.current_id) - 1) % len(ids)
        else:
            idx = 0
        self.open_item(ids[idx])

    def skip_item(self):
        if not self.current_id:
            return
        cur = self.current_id
        self.skipped[self.stage].add(cur)
        self.db.release_claim(self.stage, cur, self.reviewer)
        nxt = self.engine.next_unreviewed(self.stage, after=cur)
        if nxt and nxt != cur:
            self.open_item(nxt)
        else:
            self.status.setText("No other unreviewed item is currently available.")

    def touch_claim(self):
        if self.current_id:
            self.db.touch_claim(self.stage, self.current_id, self.reviewer)

    def release_current_claim(self):
        if self.current_id:
            try:
                self.db.release_claim(self.stage, self.current_id, self.reviewer)
            except Exception:
                pass
        self.current_id = None

    def clear_current(self):
        self.release_current_claim()
        self.item_label.setText("—")
        self.area_label.setText("—")
        self.source_label.setText("—")
        self.notes.clear()
        if self.highlight:
            self.highlight.hide()
            self.highlight.deleteLater()
            self.highlight = None

    def update_progress(self):
        try:
            reviewed, total, counts = self.engine.stage_progress(self.stage)
        except Exception:
            reviewed, total, counts = 0, 0, {}
        pct = round(100 * reviewed / total) if total else 0
        details = ", ".join(f"{k}: {v}" for k, v in counts.items() if k != "reviewed")
        self.progress_text.setText(f"{reviewed:,} / {total:,} reviewed" + (f" — {details}" if details else ""))
        self.progress.setValue(pct)

    def start_geometry_edit(self):
        if self.stage != 3 or not self.current_id:
            return
        feat, layer = self.engine.feature_for(3, self.current_id)
        if feat is None:
            return
        if not layer.isEditable():
            if not layer.startEditing():
                QMessageBox.warning(self, "Geometry editing", "The prediction layer could not be placed in edit mode.")
                return
        layer.selectByIds([feat.id()])
        self.iface.setActiveLayer(layer)
        try:
            action = getattr(self.iface, "actionVertexTool", None)
            if callable(action):
                action().trigger()
        except Exception:
            pass
        self.status.setText(
            "Prediction layer is in edit mode and the current object is selected. Edit the geometry using QGIS tools, save layer edits, then classify the object again."
        )

    def export_results(self):
        try:
            result = ExportEngine(self.engine, self.db).export(self.config["output_dir"])
            QMessageBox.information(
                self, "Waste Review export",
                f"Export complete.\n\nFinal kept objects: {result['final_objects']:,}\n"
                f"Contiguous waste piles: {result['final_units']:,}\n"
                f"Unresolved objects: {result['unresolved']:,}\n\n{result['gpkg']}"
            )
        except Exception as e:
            QMessageBox.critical(self, "Export failed", str(e))

    def closeEvent(self, event):
        self.release_current_claim()
        self.clear_current()
        super().closeEvent(event)
