import os

from qgis.PyQt.QtCore import QSettings
from qgis.PyQt.QtWidgets import (
    QDialog, QDialogButtonBox, QFileDialog, QFormLayout, QHBoxLayout,
    QLabel, QLineEdit, QPushButton, QDoubleSpinBox, QVBoxLayout, QWidget
)


SETTINGS_PREFIX = "waste_review/"


class PathRow(QWidget):
    def __init__(self, mode="file", filter_text="All files (*)", parent=None):
        super().__init__(parent)
        self.mode = mode
        self.filter_text = filter_text
        self.edit = QLineEdit()
        self.button = QPushButton("Browse…")
        self.button.clicked.connect(self.browse)
        lay = QHBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.addWidget(self.edit, 1)
        lay.addWidget(self.button)

    def browse(self):
        current = self.edit.text().strip() or os.path.expanduser("~")
        if self.mode == "dir":
            path = QFileDialog.getExistingDirectory(self, "Select folder", current)
        elif self.mode == "save":
            path, _ = QFileDialog.getSaveFileName(self, "Select file", current, self.filter_text)
        else:
            path, _ = QFileDialog.getOpenFileName(self, "Select file", current, self.filter_text)
        if path:
            self.edit.setText(path)

    def text(self):
        return self.edit.text().strip()

    def setText(self, value):
        self.edit.setText(value or "")


class ConfigDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Waste Review — Project setup")
        self.resize(760, 360)
        self.settings = QSettings()

        self.reviewer = QLineEdit()
        self.grid = PathRow("file", "GeoPackage (*.gpkg);;Vector files (*.gpkg *.shp)")
        self.predictions = PathRow("file", "Vector files (*.shp *.gpkg)")
        self.mapping = PathRow("file", "CSV (*.csv)")
        self.database = PathRow("save", "SQLite (*.sqlite *.db)")
        self.output = PathRow("dir")
        self.min_area = QDoubleSpinBox()
        self.min_area.setDecimals(3)
        self.min_area.setRange(0.0, 1000000.0)
        self.min_area.setValue(0.25)
        self.min_area.setSuffix(" m²")

        intro = QLabel(
            "Choose the same review grid, prediction polygons, object-to-chip mapping and review database used by the Shiny workflow. "
            "The prediction layer must contain candidate_id and the grid must contain chip_id."
        )
        intro.setWordWrap(True)

        form = QFormLayout()
        form.addRow("Reviewer name", self.reviewer)
        form.addRow("Review grid", self.grid)
        form.addRow("Prediction polygons", self.predictions)
        form.addRow("object_chip_map.csv", self.mapping)
        form.addRow("review_log.sqlite", self.database)
        form.addRow("Export folder", self.output)
        form.addRow("Minimum object area", self.min_area)

        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)

        lay = QVBoxLayout(self)
        lay.addWidget(intro)
        lay.addLayout(form)
        lay.addWidget(buttons)
        self.load_settings()

    def load_settings(self):
        s = self.settings
        self.reviewer.setText(s.value(SETTINGS_PREFIX + "reviewer", ""))
        self.grid.setText(s.value(SETTINGS_PREFIX + "review_grid", ""))
        self.predictions.setText(s.value(SETTINGS_PREFIX + "predictions", ""))
        self.mapping.setText(s.value(SETTINGS_PREFIX + "object_chip_map", ""))
        self.database.setText(s.value(SETTINGS_PREFIX + "database", ""))
        self.output.setText(s.value(SETTINGS_PREFIX + "output_dir", ""))
        try:
            self.min_area.setValue(float(s.value(SETTINGS_PREFIX + "min_area_m2", 0.25)))
        except Exception:
            self.min_area.setValue(0.25)

    def config(self):
        return {
            "reviewer": self.reviewer.text().strip(),
            "review_grid": self.grid.text(),
            "predictions": self.predictions.text(),
            "object_chip_map": self.mapping.text(),
            "database": self.database.text(),
            "output_dir": self.output.text(),
            "min_area_m2": float(self.min_area.value()),
        }

    def validate(self):
        cfg = self.config()
        if not cfg["reviewer"]:
            return "Enter a reviewer name."
        for key, label in [
            ("review_grid", "review grid"),
            ("predictions", "prediction polygons"),
            ("object_chip_map", "object_chip_map.csv"),
        ]:
            if not cfg[key] or not os.path.isfile(cfg[key]):
                return f"Select a valid {label} file."
        if not cfg["database"]:
            return "Select a SQLite database path."
        parent = os.path.dirname(cfg["database"])
        if parent and not os.path.isdir(parent):
            return "The database folder does not exist."
        if not cfg["output_dir"]:
            return "Select an export folder."
        os.makedirs(cfg["output_dir"], exist_ok=True)
        return None

    def accept(self):
        from qgis.PyQt.QtWidgets import QMessageBox
        error = self.validate()
        if error:
            QMessageBox.warning(self, "Waste Review", error)
            return
        cfg = self.config()
        s = self.settings
        for k, v in cfg.items():
            s.setValue(SETTINGS_PREFIX + k, v)
        super().accept()
