import os
from collections import OrderedDict

from qgis.PyQt.QtCore import Qt, QRectF, QTimer
from qgis.PyQt.QtGui import QColor, QBrush, QKeySequence, QPainter, QPen, QPixmap
from qgis.PyQt.QtWidgets import (
    QComboBox,
    QFrame,
    QGraphicsPixmapItem,
    QGraphicsRectItem,
    QGraphicsScene,
    QGraphicsView,
    QGridLayout,
    QGroupBox,
    QHBoxLayout,
    QLabel,
    QMainWindow,
    QMessageBox,
    QProgressBar,
    QPushButton,
    QScrollArea,
    QShortcut,
    QSplitter,
    QTextEdit,
    QVBoxLayout,
    QWidget,
)
from qgis.core import QgsProject, QgsRectangle
from qgis.gui import QgsHighlight

from .export_engine import ExportEngine


class ReviewGraphicsView(QGraphicsView):
    """Dedicated chip-image review canvas, modelled on the original Shiny view."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self._scene = QGraphicsScene(self)
        self.setScene(self._scene)
        self._pixmap_item = None
        self._target_item = None
        self._fit_on_resize = True
        self._current_image_path = ""
        # Keep only a handful of decoded PNGs. Stage 2 is deliberately ordered
        # by display chip, so the same image is often reused for many objects.
        self._pixmap_cache = OrderedDict()
        self._pixmap_cache_limit = 6
        self.setBackgroundBrush(QBrush(QColor(17, 17, 17)))
        # SmoothPixmapTransform is visually attractive but expensive while
        # rapidly stepping through large PNGs. Antialiasing is sufficient here.
        self.setRenderHints(QPainter.Antialiasing)
        self.setTransformationAnchor(QGraphicsView.AnchorUnderMouse)
        self.setResizeAnchor(QGraphicsView.AnchorViewCenter)
        self.setDragMode(QGraphicsView.ScrollHandDrag)
        self.setFrameShape(QFrame.NoFrame)
        self.setMinimumSize(640, 480)

    def clear_canvas(self):
        self._scene.clear()
        self._pixmap_item = None
        self._target_item = None
        self._current_image_path = ""
        self.resetTransform()
        self._fit_on_resize = True

    def show_message(self, text):
        self.clear_canvas()
        item = self._scene.addText(str(text))
        font = item.font()
        font.setPointSize(20)
        item.setFont(font)
        item.setDefaultTextColor(QColor("white"))
        rect = item.boundingRect()
        item.setPos(-rect.width() / 2.0, -rect.height() / 2.0)
        self._scene.setSceneRect(-500, -300, 1000, 600)
        self.fitInView(self._scene.sceneRect(), Qt.KeepAspectRatio)

    def _set_target_box(self, pixmap, box):
        if self._target_item is not None:
            self._scene.removeItem(self._target_item)
            self._target_item = None
        if box is None:
            return
        left, top, width, height = [float(x) for x in box]
        rect = QRectF(
            pixmap.width() * left / 100.0,
            pixmap.height() * top / 100.0,
            pixmap.width() * width / 100.0,
            pixmap.height() * height / 100.0,
        )
        self._target_item = QGraphicsRectItem(rect)
        pen = QPen(QColor(255, 235, 59))
        pen.setWidth(8)
        pen.setCosmetic(True)
        self._target_item.setPen(pen)
        self._target_item.setBrush(QBrush(Qt.NoBrush))
        self._target_item.setZValue(10)
        self._scene.addItem(self._target_item)

    def _cached_pixmap(self, image_path):
        image_path = os.path.abspath(str(image_path))
        pixmap = self._pixmap_cache.pop(image_path, None)
        if pixmap is None or pixmap.isNull():
            pixmap = QPixmap(image_path)
        if pixmap.isNull():
            return None
        self._pixmap_cache[image_path] = pixmap
        while len(self._pixmap_cache) > self._pixmap_cache_limit:
            self._pixmap_cache.popitem(last=False)
        return pixmap

    def set_image(self, image_path, box=None):
        image_path = os.path.abspath(str(image_path))

        # Fast path: Stage 2 commonly presents several objects from the same
        # 50 m chip consecutively. Reuse the already decoded pixmap and merely
        # move the yellow box. This avoids the largest source of UI stalls.
        if (
            self._pixmap_item is not None
            and self._current_image_path == image_path
            and self._pixmap_item.pixmap() is not None
        ):
            pixmap = self._pixmap_item.pixmap()
            self._set_target_box(pixmap, box)
            if self._fit_on_resize:
                self.fitInView(self._pixmap_item.boundingRect(), Qt.KeepAspectRatio)
            return True

        pixmap = self._cached_pixmap(image_path)
        if pixmap is None:
            self.show_message("Review image could not be loaded.\n" + str(image_path))
            return False

        self._scene.clear()
        self._pixmap_item = QGraphicsPixmapItem(pixmap)
        self._target_item = None
        self._scene.addItem(self._pixmap_item)
        self._scene.setSceneRect(QRectF(pixmap.rect()))
        self._current_image_path = image_path
        self._set_target_box(pixmap, box)
        self.fit_image()
        return True

    def fit_image(self):
        if self._pixmap_item is None:
            return
        self.resetTransform()
        self.fitInView(self._pixmap_item.boundingRect(), Qt.KeepAspectRatio)
        self._fit_on_resize = True

    def actual_size(self):
        if self._pixmap_item is None:
            return
        self.resetTransform()
        self._fit_on_resize = False

    def wheelEvent(self, event):
        if self._pixmap_item is None:
            return super().wheelEvent(event)
        factor = 1.18 if event.angleDelta().y() > 0 else 1.0 / 1.18
        self.scale(factor, factor)
        self._fit_on_resize = False

    def resizeEvent(self, event):
        super().resizeEvent(event)
        if self._fit_on_resize and self._pixmap_item is not None:
            self.fitInView(self._pixmap_item.boundingRect(), Qt.KeepAspectRatio)


class WasteReviewWindow(QMainWindow):
    def __init__(self, iface, engine, db, config, parent=None):
        super().__init__(parent)
        self.iface = iface
        self.engine = engine
        self.db = db
        self.config = config
        self.reviewer = config["reviewer"]
        self.stage = 1
        self.current_id = None
        self.highlight = None
        self.skipped = {1: set(), 2: set(), 3: set()}
        self.shortcuts = []
        self.key_labels = {}
        self.class_buttons = []
        self._busy = False
        self._image_load_token = 0

        self.setWindowTitle("Waste Prediction Review")
        self.setAttribute(Qt.WA_DeleteOnClose, True)
        self.resize(1500, 900)
        self.setMinimumSize(1000, 650)

        self._build_ui()
        self._register_shortcuts()
        self._bind_existing_project_layers()
        self.refresh_stage(1)

        self.heartbeat = QTimer(self)
        self.heartbeat.setInterval(120000)
        self.heartbeat.timeout.connect(self.touch_claim)
        self.heartbeat.start()

    def _build_ui(self):
        central = QWidget()
        root = QVBoxLayout(central)
        root.setContentsMargins(8, 8, 8, 8)
        root.setSpacing(8)

        title = QLabel("Waste Prediction Review")
        title.setStyleSheet("font-size: 25px; font-weight: 400;")
        root.addWidget(title)

        splitter = QSplitter(Qt.Horizontal)
        root.addWidget(splitter, 1)

        # ----------------------------- sidebar -----------------------------
        sidebar_scroll = QScrollArea()
        sidebar_scroll.setWidgetResizable(True)
        sidebar_scroll.setMinimumWidth(260)
        sidebar_scroll.setMaximumWidth(370)
        sidebar = QWidget()
        side = QVBoxLayout(sidebar)
        side.setContentsMargins(6, 6, 6, 6)
        side.setSpacing(9)

        reviewer_box = QGroupBox()
        reviewer_lay = QVBoxLayout(reviewer_box)
        reviewer_label = QLabel(f"<b>Reviewer: {self.reviewer}</b>")
        reviewer_lay.addWidget(reviewer_label)
        self.legend_label = QLabel("Red outlines = model predictions.")
        self.legend_label.setWordWrap(True)
        reviewer_lay.addWidget(self.legend_label)
        side.addWidget(reviewer_box)

        stage_box = QGroupBox("Review stage")
        stage_lay = QVBoxLayout(stage_box)
        self.stage_combo = QComboBox()
        self.stage_combo.addItem("Stage 1 — location review", 1)
        self.stage_combo.addItem("Stage 2 — object review", 2)
        self.stage_combo.addItem("Stage 3 — final audit", 3)
        self.stage_combo.currentIndexChanged.connect(self.on_stage_changed)
        stage_lay.addWidget(self.stage_combo)
        self.stage_summary = QLabel()
        self.stage_summary.setWordWrap(True)
        stage_lay.addWidget(self.stage_summary)
        self.prepare2 = QPushButton("Prepare / start second review")
        self.prepare3 = QPushButton("Prepare / start Stage 3")
        self.prepare2.clicked.connect(self.prepare_stage2)
        self.prepare3.clicked.connect(self.prepare_stage3)
        stage_lay.addWidget(self.prepare2)
        stage_lay.addWidget(self.prepare3)
        side.addWidget(stage_box)

        self.item_box = QGroupBox("Current review item")
        item_lay = QGridLayout(self.item_box)
        self.item_label = QLabel("—")
        self.area_label = QLabel("—")
        self.source_label = QLabel("—")
        self.source_label.setWordWrap(True)
        item_lay.addWidget(QLabel("ID"), 0, 0)
        item_lay.addWidget(self.item_label, 0, 1)
        item_lay.addWidget(QLabel("Area"), 1, 0)
        item_lay.addWidget(self.area_label, 1, 1)
        item_lay.addWidget(QLabel("Status"), 2, 0)
        item_lay.addWidget(self.source_label, 2, 1)
        side.addWidget(self.item_box)

        self.target_banner = QLabel()
        self.target_banner.setWordWrap(True)
        self.target_banner.setStyleSheet(
            "background:#fff9c4; border:1px solid #d6c84a; border-radius:5px; padding:8px;"
        )
        self.target_banner.setVisible(False)
        side.addWidget(self.target_banner)

        self.class_box = QGroupBox("Classification")
        self.class_layout = QVBoxLayout(self.class_box)
        side.addWidget(self.class_box)

        notes_box = QGroupBox("Notes")
        notes_lay = QVBoxLayout(notes_box)
        self.notes = QTextEdit()
        self.notes.setPlaceholderText("Optional notes")
        self.notes.setMaximumHeight(100)
        notes_lay.addWidget(self.notes)
        side.addWidget(notes_box)

        nav_box = QGroupBox("Navigation / correction")
        nav_lay = QVBoxLayout(nav_box)
        row = QHBoxLayout()
        self.prev_btn = QPushButton("◀ Previous")
        self.next_btn = QPushButton("Next ▶")
        self.prev_btn.clicked.connect(self.previous_item)
        self.next_btn.clicked.connect(self.next_item)
        row.addWidget(self.prev_btn)
        row.addWidget(self.next_btn)
        nav_lay.addLayout(row)
        self.skip_btn = QPushButton("S  Skip")
        self.skip_btn.clicked.connect(self.skip_item)
        nav_lay.addWidget(self.skip_btn)
        self.last_review_btn = QPushButton("Edit my last review")
        self.last_review_btn.clicked.connect(self.edit_last_review)
        nav_lay.addWidget(self.last_review_btn)
        side.addWidget(nav_box)

        qgis_box = QGroupBox("QGIS tools")
        qgis_lay = QVBoxLayout(qgis_box)
        self.map_btn = QPushButton("Show current item on QGIS map")
        self.map_btn.clicked.connect(self.show_on_qgis_map)
        qgis_lay.addWidget(self.map_btn)
        self.edit_btn = QPushButton("Edit current Stage-3 geometry")
        self.edit_btn.clicked.connect(self.start_geometry_edit)
        qgis_lay.addWidget(self.edit_btn)
        side.addWidget(qgis_box)

        self.status = QLabel("")
        self.status.setWordWrap(True)
        self.status.setStyleSheet("color:#555; padding:4px;")
        side.addWidget(self.status)

        export = QPushButton("Export current results")
        export.clicked.connect(self.export_results)
        side.addWidget(export)
        side.addStretch(1)
        sidebar_scroll.setWidget(sidebar)
        splitter.addWidget(sidebar_scroll)

        # ------------------------------ canvas -----------------------------
        right = QWidget()
        right_lay = QVBoxLayout(right)
        right_lay.setContentsMargins(4, 4, 4, 4)
        right_lay.setSpacing(6)

        header = QHBoxLayout()
        self.image_title = QLabel("Stage 1: review location")
        self.image_title.setStyleSheet("font-size:18px;")
        header.addWidget(self.image_title, 1)
        self.progress_text = QLabel("Reviewed 0 / 0")
        self.progress_text.setStyleSheet("font-size:18px;")
        header.addWidget(self.progress_text)
        right_lay.addLayout(header)

        self.canvas = ReviewGraphicsView()
        right_lay.addWidget(self.canvas, 1)

        image_tools = QHBoxLayout()
        fit_btn = QPushButton("Fit image")
        fit_btn.clicked.connect(self.canvas.fit_image)
        actual_btn = QPushButton("100%")
        actual_btn.clicked.connect(self.canvas.actual_size)
        image_tools.addWidget(fit_btn)
        image_tools.addWidget(actual_btn)
        image_tools.addStretch(1)
        self.progress = QProgressBar()
        self.progress.setRange(0, 100)
        self.progress.setMaximumWidth(280)
        image_tools.addWidget(self.progress)
        right_lay.addLayout(image_tools)

        splitter.addWidget(right)
        splitter.setStretchFactor(0, 0)
        splitter.setStretchFactor(1, 1)
        splitter.setSizes([300, 1200])

        self.setCentralWidget(central)
        self.rebuild_classification_buttons()
        self._refresh_stage_controls()

    def _register_shortcuts(self):
        for key, handler in [
            ("1", lambda: self.classify_by_key(1)),
            ("2", lambda: self.classify_by_key(2)),
            ("3", lambda: self.classify_by_key(3)),
            ("4", lambda: self.classify_by_key(4)),
            ("S", self.skip_item),
        ]:
            sc = QShortcut(QKeySequence(key), self)
            sc.setContext(Qt.WindowShortcut)
            sc.activated.connect(handler)
            self.shortcuts.append(sc)

    def rebuild_classification_buttons(self):
        self.class_buttons = []
        while self.class_layout.count():
            item = self.class_layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()

        if self.stage == 1:
            spec = [
                (1, "Waste", "waste", "#e8f5e9", "#a5d6a7"),
                (2, "Not waste", "not_waste", "#ffebee", "#ef9a9a"),
                (3, "Waste + false positives", "mixed", "#fff8e1", "#ffe082"),
                (4, "Not sure", "not_sure", "#f5f5f5", "#bdbdbd"),
            ]
        elif self.stage == 2:
            spec = [
                (1, "Waste", "waste", "#e8f5e9", "#a5d6a7"),
                (2, "Not waste", "not_waste", "#ffebee", "#ef9a9a"),
                (3, "Not sure", "not_sure", "#f5f5f5", "#bdbdbd"),
            ]
        else:
            spec = [
                (1, "Keep", "keep", "#e8f5e9", "#a5d6a7"),
                (2, "Delete", "delete", "#ffebee", "#ef9a9a"),
                (3, "Needs edit", "needs_edit", "#fff8e1", "#ffe082"),
                (4, "Not sure", "not_sure", "#f5f5f5", "#bdbdbd"),
            ]

        self.key_labels = {}
        for key, text, label, bg, border in spec:
            btn = QPushButton(f"{key}  {text}")
            btn.setMinimumHeight(44)
            btn.setStyleSheet(
                f"QPushButton {{background:{bg}; border:1px solid {border}; border-radius:5px; font-size:16px;}}"
                "QPushButton:hover {font-weight:600;}"
            )
            btn.clicked.connect(lambda checked=False, lab=label: self.save_label(lab))
            self.class_layout.addWidget(btn)
            self.class_buttons.append(btn)
            self.key_labels[key] = label
        self.edit_btn.setVisible(self.stage == 3)

    def classify_by_key(self, key):
        if self._busy:
            return
        label = self.key_labels.get(key)
        if label and self.current_id:
            self.save_label(label)

    def _refresh_stage_controls(self):
        self.prepare2.setVisible(self.stage == 1)
        self.prepare3.setVisible(self.stage in (1, 2))
        self.edit_btn.setVisible(self.stage == 3)
        if self.stage == 1:
            self.legend_label.setText("Red outlines = model predictions.")
            self.image_title.setText("Stage 1: review location")
            self.target_banner.setVisible(False)
        elif self.stage == 2:
            self.legend_label.setText("Yellow box = current Stage-2 object. The image inside the box is unchanged.")
            self.image_title.setText("Stage 2: review object inside yellow bounding box")
            self.target_banner.setText(
                "Review only the object inside the YELLOW bounding box. The box is transparent and does not colour the target."
            )
            self.target_banner.setVisible(True)
        else:
            self.legend_label.setText("Yellow box = current Stage-3 retained object. Check whether it should remain in the final inventory.")
            self.image_title.setText("Stage 3: final positive audit")
            self.target_banner.setText(
                "FINAL POSITIVE AUDIT: inspect the object inside the YELLOW box and decide whether it should remain in the final waste inventory."
            )
            self.target_banner.setVisible(True)
        self.rebuild_classification_buttons()
        self.update_stage_summary()

    def update_stage_summary(self):
        try:
            s1 = self.db.counts(1)
            total1 = len(self.engine.stage1_items())
            reviewed1 = int(s1.get("reviewed", 0))
            if self.stage == 1:
                remain = max(0, total1 - reviewed1)
                text = f"STAGE 1 — LOCATION REVIEW\n{reviewed1:,} / {total1:,} locations reviewed."
                if remain == 0:
                    text += "\n\nSTAGE 2 — OBJECT REVIEW\nStage 1 is complete. Stage 2 is ready to prepare."
                else:
                    text += f"\n\nStage 2 becomes available after the remaining {remain:,} location(s) are reviewed."
            elif self.stage == 2:
                reviewed, total, _ = self.engine.stage_progress(2)
                text = f"STAGE 2 — OBJECT REVIEW\n{reviewed:,} / {total:,} objects reviewed.\nMinimum object area: {self.engine.min_area:g} m²."
            else:
                reviewed, total, _ = self.engine.stage_progress(3)
                text = f"STAGE 3 — FINAL POSITIVE AUDIT\n{reviewed:,} / {total:,} retained objects audited."
            self.stage_summary.setText(text)
        except Exception as exc:
            self.stage_summary.setText(str(exc))

    def on_stage_changed(self):
        self.release_current_claim()
        self.stage = int(self.stage_combo.currentData())
        self._refresh_stage_controls()
        self.refresh_stage(self.stage)

    def prepare_stage2(self):
        try:
            ids = self.engine.prepare_stage2()
            self.status.setText(f"Stage 2 prepared: {len(ids):,} object(s).")
            self.stage_combo.setCurrentIndex(1)
        except Exception as exc:
            QMessageBox.warning(self, "Stage 2", str(exc))

    def prepare_stage3(self):
        try:
            ids = self.engine.prepare_stage3()
            self.status.setText(f"Stage 3 prepared: {len(ids):,} positive object(s).")
            self.stage_combo.setCurrentIndex(2)
        except Exception as exc:
            QMessageBox.warning(self, "Stage 3", str(exc))

    def refresh_stage(self, stage):
        try:
            ids = self.engine.active_ids(stage)
        except Exception as exc:
            self.clear_current()
            self.canvas.show_message(str(exc))
            self.status.setText(str(exc))
            self.update_progress()
            return

        current = self.db.current(stage)
        target = None
        for item_id in ids:
            if str(item_id) not in current and str(item_id) not in self.skipped[stage]:
                target = str(item_id)
                break

        if target is not None:
            self.open_item(target)
        else:
            self.clear_current()
            if stage == 1:
                self.canvas.show_message("First review complete.")
                self.status.setText("Use 'Prepare / start second review' to continue.")
            elif stage == 2:
                self.canvas.show_message("Second review complete.")
                self.status.setText("Stage 2 has no unreviewed objects remaining.")
            else:
                self.canvas.show_message("Final positive audit complete.")
                self.status.setText("Stage 3 has no unreviewed objects remaining.")
        self.update_progress()
        self.update_stage_summary()

    def open_item(self, item_id):
        self.release_current_claim()
        item_id = str(item_id)
        row = self.db.get(self.stage, item_id)

        if not self.db.claim(self.stage, item_id, self.reviewer):
            nxt = self.engine.next_unreviewed(self.stage, after=item_id)
            if nxt and nxt != item_id:
                return self.open_item(nxt)
            self.status.setText("This item is open in another review session.")
            return

        self.current_id = item_id
        self.notes.setPlainText(row.get("notes", "") if row else "")

        self.item_label.setText(item_id)
        if self.stage == 1:
            self.area_label.setText("50 m review location")
            nobj = self.engine.chip_n_objects.get(item_id, len(self.engine.chip_to_candidates.get(item_id, [])))
            self.source_label.setText(
                (f"{nobj:,} candidate prediction(s)" if nobj else "No mapped candidate count")
                + (f"; current label: {row['label']}" if row else "; unreviewed")
            )
        else:
            area = self.engine.pred_area_m2.get(item_id, 0.0)
            self.area_label.setText(f"{area:,.2f} m²")
            if self.stage == 2:
                self.source_label.setText(f"First-stage reason: {self.engine.stage1_reason.get(item_id, '')}")
            else:
                src = self.engine.review_source.get(item_id, "positive inventory")
                self.source_label.setText(f"Entered Stage 3 from: {src}")

        # Let Qt repaint the labels before decoding a PNG. This prevents the
        # window from appearing frozen even when an image is on a slow disk.
        self._image_load_token += 1
        token = self._image_load_token
        self.status.setText("Loading review image…")
        QTimer.singleShot(0, lambda iid=item_id, was_reviewed=bool(row), tok=token: self._load_item_image(iid, was_reviewed, tok))
        self.update_progress()

    def _load_item_image(self, item_id, was_reviewed, token):
        if token != self._image_load_token or str(item_id) != str(self.current_id):
            return
        try:
            info = self.engine.review_image_info(self.stage, item_id)
            if info and info.get("image_path"):
                self.canvas.set_image(info["image_path"], info.get("box"))
                self.status.setText(
                    "Previously reviewed — change the label to correct it."
                    if was_reviewed else "Ready for review."
                )
            else:
                self.canvas.show_message(
                    "No prepared review PNG is available for this item.\n\n"
                    "Use 'Show current item on QGIS map' or configure chips.csv and the PNG chip folder."
                )
                self.status.setText("Review canvas image unavailable; QGIS map fallback remains available.")
        except Exception as exc:
            self.canvas.show_message("Could not load review image.\n" + str(exc))
            self.status.setText(str(exc))

    def _set_review_buttons_enabled(self, enabled):
        for btn in self.class_buttons:
            btn.setEnabled(bool(enabled))
        self.skip_btn.setEnabled(bool(enabled))
        self.prev_btn.setEnabled(bool(enabled))
        self.next_btn.setEnabled(bool(enabled))

    def save_label(self, label):
        if not self.current_id or self._busy:
            return
        self._busy = True
        self._set_review_buttons_enabled(False)
        previous = str(self.current_id)
        try:
            self.db.save(self.stage, previous, label, self.reviewer, self.notes.toPlainText())
            if self.stage == 1:
                # Only predictions touching the reviewed cell can change their
                # Stage-1 routing status; do not recompute every prediction.
                self.engine.refresh_stage1_for_chip(previous)
            self.status.setText("Saved. Loading next item…")
            self.update_progress()
            self.update_stage_summary()
            # Yield to the event loop before loading the next image.
            QTimer.singleShot(0, lambda prev=previous: self._advance_after_save(prev))
        except Exception as exc:
            self._busy = False
            self._set_review_buttons_enabled(True)
            QMessageBox.critical(self, "Waste Review", str(exc))

    def _advance_after_save(self, previous):
        try:
            nxt = self.engine.next_unreviewed(self.stage, after=previous)
            if nxt:
                self.open_item(nxt)
            else:
                self.refresh_stage(self.stage)
        finally:
            self._busy = False
            self._set_review_buttons_enabled(True)

    def next_item(self):
        ids = self.engine.active_ids(self.stage)
        if not ids:
            return
        if self.current_id in ids:
            idx = (ids.index(self.current_id) + 1) % len(ids)
        else:
            idx = 0
        self.open_item(ids[idx])

    def previous_item(self):
        ids = self.engine.active_ids(self.stage)
        if not ids:
            return
        if self.current_id in ids:
            idx = (ids.index(self.current_id) - 1) % len(ids)
        else:
            idx = len(ids) - 1
        self.open_item(ids[idx])

    def edit_last_review(self):
        rows = self.db.current(self.stage)
        mine = [(item_id, row) for item_id, row in rows.items() if row.get("annotator") == self.reviewer]
        if not mine:
            self.status.setText("You have no previous review in this stage.")
            return
        mine.sort(key=lambda x: x[1].get("timestamp", ""), reverse=True)
        self.open_item(mine[0][0])

    def skip_item(self):
        if not self.current_id:
            return
        cur = self.current_id
        self.skipped[self.stage].add(cur)
        self.db.release_claim(self.stage, cur, self.reviewer)
        self.current_id = None
        nxt = self.engine.next_unreviewed(self.stage, after=cur)
        if nxt and nxt != cur:
            self.open_item(nxt)
        else:
            self.status.setText("No other unreviewed item is currently available.")

    def update_progress(self):
        try:
            reviewed, total, _ = self.engine.stage_progress(self.stage)
        except Exception:
            reviewed, total = 0, 0
        pct = round(100 * reviewed / total) if total else 0
        self.progress_text.setText(f"Reviewed {reviewed:,} / {total:,}")
        self.progress.setValue(pct)

    def touch_claim(self):
        if self.current_id:
            try:
                self.db.touch_claim(self.stage, self.current_id, self.reviewer)
            except Exception:
                pass

    def release_current_claim(self):
        if self.current_id:
            try:
                self.db.release_claim(self.stage, self.current_id, self.reviewer)
            except Exception:
                pass
        self.current_id = None

    def clear_current(self):
        self.release_current_claim()
        self.item_label.setText("—")
        self.area_label.setText("—")
        self.source_label.setText("—")
        self.notes.clear()
        if self.highlight:
            self.highlight.hide()
            self.highlight.deleteLater()
            self.highlight = None

    @staticmethod
    def _source_key(layer):
        if layer is None:
            return ""
        try:
            return str(layer.source()).replace("\\", "/").lower()
        except Exception:
            return ""

    def _matching_project_layer(self, target_layer):
        if target_layer is None:
            return None
        project = QgsProject.instance()
        if target_layer.id() in project.mapLayers():
            return project.mapLayer(target_layer.id())
        target_key = self._source_key(target_layer)
        target_base = target_key.split("|", 1)[0]
        for layer in project.mapLayers().values():
            source_key = self._source_key(layer)
            if source_key == target_key:
                return layer
            if target_base and source_key.split("|", 1)[0] == target_base:
                return layer
        return None

    def _bind_existing_project_layers(self):
        grid = self._matching_project_layer(self.engine.grid_layer)
        pred = self._matching_project_layer(self.engine.pred_layer)
        grid_changed = grid is not None and grid is not self.engine.grid_layer
        pred_changed = pred is not None and pred is not self.engine.pred_layer
        if grid_changed:
            self.engine.grid_layer = grid
            self.engine.grid_feature_by_chip = {
                str(f["chip_id"]): f for f in self.engine.grid_layer.getFeatures()
            }
        if pred_changed:
            self.engine.pred_layer = pred
            # A rescan is necessary only if we actually switched to a different
            # project-owned layer. Engine.load() has already built this cache.
            self.engine.refresh_prediction_cache()
        if grid_changed or pred_changed:
            self.engine.refresh_stage1_status()

    def show_on_qgis_map(self):
        if not self.current_id:
            return
        feat, layer = self.engine.feature_for(self.stage, self.current_id)
        if feat is None:
            self.status.setText("Current feature could not be located in the spatial layer.")
            return
        if self.highlight:
            self.highlight.hide()
            self.highlight.deleteLater()
            self.highlight = None
        self.highlight = QgsHighlight(self.iface.mapCanvas(), feat.geometry(), layer)
        self.highlight.setWidth(4)
        self.highlight.setBuffer(1)
        self.highlight.show()

        extent = feat.geometry().boundingBox()
        if not extent.isEmpty():
            if self.stage == 1:
                extent.scale(1.25)
            else:
                width = max(extent.width(), 20.0)
                height = max(extent.height(), 20.0)
                cx = extent.center().x()
                cy = extent.center().y()
                extent = QgsRectangle(cx - width, cy - height, cx + width, cy + height)
            self.iface.mapCanvas().setExtent(extent)
            self.iface.mapCanvas().refresh()
        self.status.setText("Current review item shown on the QGIS map canvas.")

    def start_geometry_edit(self):
        if self.stage != 3 or not self.current_id:
            return
        feat, layer = self.engine.feature_for(3, self.current_id)
        if feat is None:
            return
        project_layer = self._matching_project_layer(layer)
        if project_layer is None:
            QMessageBox.information(
                self,
                "Geometry editing",
                "For Stage-3 geometry editing, first add the prediction layer to the QGIS project using "
                "Layer → Add Layer → Add Vector Layer, then click this button again.\n\nPrediction source:\n"
                + str(layer.source()),
            )
            return
        if project_layer is not self.engine.pred_layer:
            self.engine.pred_layer = project_layer
            self.engine.refresh_prediction_cache()
            feat, layer = self.engine.feature_for(3, self.current_id)
            if feat is None:
                QMessageBox.warning(self, "Geometry editing", "The current candidate could not be found in the loaded prediction layer.")
                return
        else:
            layer = project_layer
        if not layer.isEditable() and not layer.startEditing():
            QMessageBox.warning(self, "Geometry editing", "The prediction layer could not be placed in edit mode.")
            return
        layer.selectByIds([feat.id()])
        self.iface.setActiveLayer(layer)
        try:
            action = getattr(self.iface, "actionVertexTool", None)
            if callable(action):
                action().trigger()
        except Exception:
            pass
        self.status.setText("Prediction layer is in edit mode. Edit the selected object in QGIS, save layer edits, then return here and classify it again.")

    def export_results(self):
        try:
            result = ExportEngine(self.engine, self.db).export(self.config["output_dir"])
            QMessageBox.information(
                self,
                "Waste Review export",
                f"Export complete.\n\nFinal kept objects: {result['final_objects']:,}\n"
                f"Contiguous waste piles: {result['final_units']:,}\n"
                f"Unresolved objects: {result['unresolved']:,}\n\n{result['gpkg']}",
            )
        except Exception as exc:
            QMessageBox.critical(self, "Export failed", str(exc))

    def closeEvent(self, event):
        self.release_current_claim()
        if self.highlight:
            self.highlight.hide()
            self.highlight.deleteLater()
            self.highlight = None
        super().closeEvent(event)
