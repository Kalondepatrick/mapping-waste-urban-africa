import json
import os
import sqlite3
import time
from contextlib import contextmanager
from datetime import datetime, timedelta


VALID_LABELS = {
    1: {"waste", "not_waste", "mixed", "not_sure"},
    2: {"waste", "not_waste", "not_sure"},
    3: {"keep", "delete", "needs_edit", "not_sure"},
}

TABLES = {
    1: ("annotations", "annotation_history", "claims", "chip_id"),
    2: ("second_review", "second_review_history", "second_claims", "candidate_id"),
    3: ("third_review", "third_review_history", "third_claims", "candidate_id"),
}


def now_text():
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


class ReviewDatabase:
    def __init__(self, path, claim_timeout_minutes=30):
        self.path = path
        self.claim_timeout_minutes = int(claim_timeout_minutes)
        self._current_cache = {1: None, 2: None, 3: None}
        self._current_cache_time = {1: 0.0, 2: 0.0, 3: 0.0}
        # A short cache collapses the several progress/routing reads generated
        # by one click while still allowing other reviewers to appear quickly.
        self._cache_ttl_seconds = 0.75
        self.init_db()

    @contextmanager
    def connect(self):
        con = sqlite3.connect(self.path, timeout=5)
        con.row_factory = sqlite3.Row
        con.execute("PRAGMA busy_timeout=5000;")
        try:
            yield con
            con.commit()
        except Exception:
            con.rollback()
            raise
        finally:
            con.close()

    def init_db(self):
        with self.connect() as con:
            # WAL mode persists in the database; setting it on every connection
            # causes unnecessary lock negotiation during rapid annotation.
            con.execute("PRAGMA journal_mode=WAL;")
            con.executescript(
                """
                CREATE TABLE IF NOT EXISTS annotations (
                  chip_id TEXT PRIMARY KEY,
                  label TEXT NOT NULL,
                  annotator TEXT NOT NULL,
                  notes TEXT,
                  timestamp TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS annotation_history (
                  id INTEGER PRIMARY KEY AUTOINCREMENT,
                  chip_id TEXT NOT NULL,
                  label TEXT NOT NULL,
                  annotator TEXT NOT NULL,
                  notes TEXT,
                  timestamp TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS claims (
                  chip_id TEXT PRIMARY KEY,
                  annotator TEXT NOT NULL,
                  claimed_at TEXT NOT NULL
                );

                CREATE TABLE IF NOT EXISTS second_review (
                  candidate_id TEXT PRIMARY KEY,
                  label TEXT NOT NULL,
                  annotator TEXT NOT NULL,
                  notes TEXT,
                  timestamp TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS second_review_history (
                  id INTEGER PRIMARY KEY AUTOINCREMENT,
                  candidate_id TEXT NOT NULL,
                  label TEXT NOT NULL,
                  annotator TEXT NOT NULL,
                  notes TEXT,
                  timestamp TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS second_claims (
                  candidate_id TEXT PRIMARY KEY,
                  annotator TEXT NOT NULL,
                  claimed_at TEXT NOT NULL
                );

                CREATE TABLE IF NOT EXISTS third_review (
                  candidate_id TEXT PRIMARY KEY,
                  label TEXT NOT NULL,
                  annotator TEXT NOT NULL,
                  notes TEXT,
                  timestamp TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS third_review_history (
                  id INTEGER PRIMARY KEY AUTOINCREMENT,
                  candidate_id TEXT NOT NULL,
                  label TEXT NOT NULL,
                  annotator TEXT NOT NULL,
                  notes TEXT,
                  timestamp TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS third_claims (
                  candidate_id TEXT PRIMARY KEY,
                  annotator TEXT NOT NULL,
                  claimed_at TEXT NOT NULL
                );

                CREATE INDEX IF NOT EXISTS idx_annotations_label ON annotations(label);
                CREATE INDEX IF NOT EXISTS idx_annotations_annotator ON annotations(annotator);
                CREATE INDEX IF NOT EXISTS idx_second_label ON second_review(label);
                CREATE INDEX IF NOT EXISTS idx_second_annotator ON second_review(annotator);
                CREATE INDEX IF NOT EXISTS idx_third_label ON third_review(label);
                CREATE INDEX IF NOT EXISTS idx_third_annotator ON third_review(annotator);

                CREATE TABLE IF NOT EXISTS project_metadata (
                  key TEXT PRIMARY KEY,
                  value TEXT NOT NULL
                );
                """
            )

    def _parts(self, stage):
        return TABLES[int(stage)]

    def release_expired_claims(self, stage):
        _, _, claims, key = self._parts(stage)
        cutoff = (datetime.now() - timedelta(minutes=self.claim_timeout_minutes)).strftime(
            "%Y-%m-%d %H:%M:%S"
        )
        with self.connect() as con:
            con.execute(f"DELETE FROM {claims} WHERE claimed_at < ?", (cutoff,))

    def claim(self, stage, item_id, annotator):
        _, _, claims, key = self._parts(stage)
        self.release_expired_claims(stage)
        with self.connect() as con:
            row = con.execute(
                f"SELECT annotator FROM {claims} WHERE {key} = ?", (str(item_id),)
            ).fetchone()
            if row and row["annotator"] != annotator:
                return False
            if row:
                con.execute(
                    f"UPDATE {claims} SET claimed_at=? WHERE {key}=? AND annotator=?",
                    (now_text(), str(item_id), annotator),
                )
            else:
                con.execute(
                    f"INSERT OR IGNORE INTO {claims} ({key}, annotator, claimed_at) VALUES (?, ?, ?)",
                    (str(item_id), annotator, now_text()),
                )
                row = con.execute(
                    f"SELECT annotator FROM {claims} WHERE {key} = ?", (str(item_id),)
                ).fetchone()
                if not row or row["annotator"] != annotator:
                    return False
        return True

    def touch_claim(self, stage, item_id, annotator):
        _, _, claims, key = self._parts(stage)
        with self.connect() as con:
            con.execute(
                f"UPDATE {claims} SET claimed_at=? WHERE {key}=? AND annotator=?",
                (now_text(), str(item_id), annotator),
            )

    def release_claim(self, stage, item_id, annotator=None):
        _, _, claims, key = self._parts(stage)
        with self.connect() as con:
            if annotator:
                con.execute(
                    f"DELETE FROM {claims} WHERE {key}=? AND annotator=?",
                    (str(item_id), annotator),
                )
            else:
                con.execute(f"DELETE FROM {claims} WHERE {key}=?", (str(item_id),))

    def save(self, stage, item_id, label, annotator, notes=""):
        stage = int(stage)
        if label not in VALID_LABELS[stage]:
            raise ValueError(f"Invalid Stage-{stage} label: {label}")
        table, history, claims, key = self._parts(stage)
        ts = now_text()
        with self.connect() as con:
            existing = con.execute(
                f"SELECT annotator FROM {table} WHERE {key}=?", (str(item_id),)
            ).fetchone()
            if existing and existing["annotator"] != annotator:
                raise PermissionError(
                    f"This item is currently assigned to {existing['annotator']}. "
                    "You can only correct your own current reviews."
                )
            con.execute(
                f"INSERT INTO {history} ({key}, label, annotator, notes, timestamp) VALUES (?, ?, ?, ?, ?)",
                (str(item_id), label, annotator, notes or "", ts),
            )
            con.execute(
                f"""
                INSERT INTO {table} ({key}, label, annotator, notes, timestamp)
                VALUES (?, ?, ?, ?, ?)
                ON CONFLICT({key}) DO UPDATE SET
                  label=excluded.label,
                  annotator=excluded.annotator,
                  notes=excluded.notes,
                  timestamp=excluded.timestamp
                """,
                (str(item_id), label, annotator, notes or "", ts),
            )
            con.execute(f"DELETE FROM {claims} WHERE {key}=?", (str(item_id),))

        cache = self._current_cache.get(stage)
        if cache is not None:
            cache[str(item_id)] = {
                key: str(item_id),
                "label": label,
                "annotator": annotator,
                "notes": notes or "",
                "timestamp": ts,
            }
            self._current_cache_time[stage] = time.monotonic()

    def current(self, stage, force=False):
        stage = int(stage)
        now = time.monotonic()
        cached = self._current_cache.get(stage)
        if (
            not force
            and cached is not None
            and now - self._current_cache_time.get(stage, 0.0) < self._cache_ttl_seconds
        ):
            return cached
        table, _, _, key = self._parts(stage)
        with self.connect() as con:
            rows = con.execute(
                f"SELECT {key}, label, annotator, notes, timestamp FROM {table}"
            ).fetchall()
        data = {str(r[key]): dict(r) for r in rows}
        self._current_cache[stage] = data
        self._current_cache_time[stage] = now
        return data

    def get(self, stage, item_id):
        table, _, _, key = self._parts(stage)
        with self.connect() as con:
            row = con.execute(
                f"SELECT {key}, label, annotator, notes, timestamp FROM {table} WHERE {key}=?",
                (str(item_id),),
            ).fetchone()
        return dict(row) if row else None

    def counts(self, stage, active_ids=None):
        current = self.current(stage)
        if active_ids is not None:
            ids = {str(x) for x in active_ids}
            current = {k: v for k, v in current.items() if k in ids}
        out = {"reviewed": len(current)}
        for row in current.values():
            out[row["label"]] = out.get(row["label"], 0) + 1
        return out

    def save_project_config(self, config):
        """Store project paths/settings in the review database for one-click reopening."""
        keys = (
            "project_name",
            "review_grid",
            "predictions",
            "object_chip_map",
            "chips_csv",
            "chips_dir",
            "output_dir",
            "min_area_m2",
        )
        payload = {}
        for key in keys:
            value = config.get(key)
            if key in {"review_grid", "predictions", "object_chip_map", "chips_csv", "chips_dir", "output_dir"} and value:
                value = os.path.abspath(str(value))
            payload[key] = value
        with self.connect() as con:
            for key, value in payload.items():
                con.execute(
                    """
                    INSERT INTO project_metadata (key, value) VALUES (?, ?)
                    ON CONFLICT(key) DO UPDATE SET value=excluded.value
                    """,
                    (key, json.dumps(value)),
                )

    def project_config(self):
        with self.connect() as con:
            rows = con.execute("SELECT key, value FROM project_metadata").fetchall()
        out = {}
        for row in rows:
            try:
                out[row["key"]] = json.loads(row["value"])
            except Exception:
                out[row["key"]] = row["value"]
        return out
