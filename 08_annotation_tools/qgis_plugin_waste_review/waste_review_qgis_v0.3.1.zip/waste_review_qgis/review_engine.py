import csv
import os
from collections import defaultdict

from qgis.PyQt.QtCore import QVariant
from qgis.core import (
    QgsCoordinateTransform,
    QgsDistanceArea,
    QgsFeature,
    QgsGeometry,
    QgsField,
    QgsProject,
    QgsVectorFileWriter,
    QgsVectorLayer,
    QgsWkbTypes,
)


class ReviewEngine:
    def __init__(self, config, db):
        self.config = config
        self.db = db
        self.grid_layer = None
        self.pred_layer = None
        self.object_chip_map = defaultdict(list)
        self.chip_to_candidates = defaultdict(list)
        self.chip_image_file = {}
        self.chip_n_objects = {}
        self.stage_display_meta = {2: {}, 3: {}}
        self.stage_display_order = {2: [], 3: []}
        self.grid_feature_by_chip = {}
        self.pred_feature_by_candidate = {}
        self.pred_area_m2 = {}
        self.stage1_status = {}
        self.stage1_reason = {}
        self.representative_chip = {}
        self.stage2_ids = []
        self.stage3_ids = []
        self.review_source = {}
        self.distance_area = QgsDistanceArea()
        self.load()

    def _vector_layer(self, path, name):
        layer = QgsVectorLayer(path, name, "ogr")
        if not layer.isValid():
            raise RuntimeError(f"Could not load {name}: {path}")
        return layer

    def _read_object_chip_map(self):
        """Read the mapping first because it defines the authoritative candidate IDs."""
        self.object_chip_map.clear()
        self.chip_to_candidates.clear()
        ordered_candidate_ids = []
        seen = set()

        with open(self.config["object_chip_map"], newline="", encoding="utf-8-sig") as fh:
            reader = csv.DictReader(fh)
            need = {"candidate_id", "chip_id"}
            if not need.issubset(set(reader.fieldnames or [])):
                raise RuntimeError("object_chip_map.csv must contain candidate_id and chip_id.")
            for row in reader:
                cid = str(row["candidate_id"]).strip()
                chip = str(row["chip_id"]).strip()
                if not cid:
                    raise RuntimeError("object_chip_map.csv contains a blank candidate_id.")
                if not chip:
                    raise RuntimeError(f"object_chip_map.csv contains a blank chip_id for candidate {cid}.")
                if cid not in seen:
                    seen.add(cid)
                    ordered_candidate_ids.append(cid)
                if chip not in self.object_chip_map[cid]:
                    self.object_chip_map[cid].append(chip)
                if cid not in self.chip_to_candidates[chip]:
                    self.chip_to_candidates[chip].append(cid)

        if not ordered_candidate_ids:
            raise RuntimeError("object_chip_map.csv contains no candidate IDs.")
        return ordered_candidate_ids


    def _read_chip_metadata(self):
        """Read Shiny chip metadata used by the dedicated review canvas."""
        self.chip_image_file = {}
        self.chip_n_objects = {}
        path = str(self.config.get("chips_csv") or "").strip()
        chips_dir = str(self.config.get("chips_dir") or "").strip()
        if not path or not os.path.isfile(path) or not chips_dir or not os.path.isdir(chips_dir):
            return

        with open(path, newline="", encoding="utf-8-sig") as fh:
            reader = csv.DictReader(fh)
            need = {"chip_id", "image_file"}
            if not need.issubset(set(reader.fieldnames or [])):
                raise RuntimeError("chips.csv must contain chip_id and image_file.")
            for row in reader:
                chip = str(row.get("chip_id", "")).strip()
                image_file = str(row.get("image_file", "")).strip()
                if not chip or not image_file:
                    continue
                self.chip_image_file[chip] = image_file
                try:
                    self.chip_n_objects[chip] = int(float(row.get("n_objects", 0) or 0))
                except Exception:
                    self.chip_n_objects[chip] = len(self.chip_to_candidates.get(chip, []))

    def _prepared_candidate_path(self, stage):
        data_dir = os.path.dirname(os.path.abspath(self.config["object_chip_map"]))
        name = "second_review_candidates.csv" if int(stage) == 2 else "third_review_candidates.csv"
        return os.path.join(data_dir, name)

    def _read_prepared_display_metadata(self, stage):
        """Reuse Shiny's precomputed image/bounding-box metadata when available."""
        stage = int(stage)
        self.stage_display_meta[stage] = {}
        self.stage_display_order[stage] = []
        path = self._prepared_candidate_path(stage)
        if not os.path.isfile(path):
            return
        with open(path, newline="", encoding="utf-8-sig") as fh:
            reader = csv.DictReader(fh)
            fields = set(reader.fieldnames or [])
            if "candidate_id" not in fields:
                return
            for row in reader:
                cid = str(row.get("candidate_id", "")).strip()
                if not cid:
                    continue
                meta = dict(row)
                for key in ("box_left_pct", "box_top_pct", "box_width_pct", "box_height_pct", "area_m2"):
                    try:
                        meta[key] = float(meta[key]) if meta.get(key) not in (None, "") else None
                    except Exception:
                        meta[key] = None
                self.stage_display_meta[stage][cid] = meta
                self.stage_display_order[stage].append(cid)

    @property
    def has_review_canvas(self):
        chips_dir = str(self.config.get("chips_dir") or "").strip()
        return bool(self.chip_image_file and chips_dir and os.path.isdir(chips_dir))

    def _image_path_for_file(self, image_file):
        if not image_file:
            return ""
        path = os.path.join(str(self.config.get("chips_dir") or ""), str(image_file))
        return os.path.abspath(path) if os.path.isfile(path) else ""

    def _prediction_geometry_in_grid_crs(self, candidate_id):
        feat = self.pred_feature_by_candidate.get(str(candidate_id))
        if feat is None:
            return None
        geom = QgsGeometry(feat.geometry())
        if self.pred_layer.crs() != self.grid_layer.crs():
            transform = QgsCoordinateTransform(
                self.pred_layer.crs(), self.grid_layer.crs(), QgsProject.instance().transformContext()
            )
            geom.transform(transform)
        return geom

    def _choose_display_chip(self, candidate_id):
        cid = str(candidate_id)
        mapped = [ch for ch in self.object_chip_map.get(cid, []) if ch in self.grid_feature_by_chip]
        if not mapped:
            return self.representative_chip.get(cid)

        geom = self._prediction_geometry_in_grid_crs(cid)
        if geom is None or geom.isEmpty():
            return mapped[0]
        point = geom.pointOnSurface()
        point_hits = []
        polygon_hits = []
        for ch in mapped:
            cell_geom = self.grid_feature_by_chip[ch].geometry()
            try:
                if cell_geom.intersects(point):
                    point_hits.append(ch)
                if cell_geom.intersects(geom):
                    polygon_hits.append(ch)
            except Exception:
                pass
        candidates = point_hits or polygon_hits or mapped
        s1 = self.db.current(1)
        ambiguous = [
            ch for ch in candidates
            if s1.get(ch, {"label": "unreviewed"}).get("label") in {"mixed", "not_sure"}
        ]
        return (ambiguous or candidates)[0]

    @staticmethod
    def _bbox_percent(target_rect, chip_rect, padding_pct=0.50, min_box_pct=3.0):
        chip_width = float(chip_rect.width())
        chip_height = float(chip_rect.height())
        if chip_width <= 0 or chip_height <= 0:
            return (48.5, 48.5, 3.0, 3.0)

        xmin = max(float(target_rect.xMinimum()), float(chip_rect.xMinimum()))
        xmax = min(float(target_rect.xMaximum()), float(chip_rect.xMaximum()))
        ymin = max(float(target_rect.yMinimum()), float(chip_rect.yMinimum()))
        ymax = min(float(target_rect.yMaximum()), float(chip_rect.yMaximum()))

        if xmax <= xmin or ymax <= ymin:
            cx_map = (float(target_rect.xMinimum()) + float(target_rect.xMaximum())) / 2.0
            cy_map = (float(target_rect.yMinimum()) + float(target_rect.yMaximum())) / 2.0
            cx = 100.0 * (cx_map - float(chip_rect.xMinimum())) / chip_width
            cy = 100.0 * (float(chip_rect.yMaximum()) - cy_map) / chip_height
            cx = min(100.0 - min_box_pct / 2.0, max(min_box_pct / 2.0, cx))
            cy = min(100.0 - min_box_pct / 2.0, max(min_box_pct / 2.0, cy))
            return (cx - min_box_pct / 2.0, cy - min_box_pct / 2.0, min_box_pct, min_box_pct)

        left = 100.0 * (xmin - float(chip_rect.xMinimum())) / chip_width
        right = 100.0 * (xmax - float(chip_rect.xMinimum())) / chip_width
        top = 100.0 * (float(chip_rect.yMaximum()) - ymax) / chip_height
        bottom = 100.0 * (float(chip_rect.yMaximum()) - ymin) / chip_height

        left -= padding_pct
        right += padding_pct
        top -= padding_pct
        bottom += padding_pct

        if right - left < min_box_pct:
            centre = (left + right) / 2.0
            left = centre - min_box_pct / 2.0
            right = centre + min_box_pct / 2.0
        if bottom - top < min_box_pct:
            centre = (top + bottom) / 2.0
            top = centre - min_box_pct / 2.0
            bottom = centre + min_box_pct / 2.0

        if left < 0.3:
            shift = 0.3 - left
            left += shift
            right += shift
        if right > 99.7:
            shift = right - 99.7
            left -= shift
            right -= shift
        if top < 0.3:
            shift = 0.3 - top
            top += shift
            bottom += shift
        if bottom > 99.7:
            shift = bottom - 99.7
            top -= shift
            bottom -= shift

        return (left, top, right - left, bottom - top)

    def review_image_info(self, stage, item_id):
        """Return the PNG and optional yellow-box coordinates for the review canvas."""
        stage = int(stage)
        item_id = str(item_id)
        if not self.has_review_canvas:
            return None

        if stage == 1:
            image_file = self.chip_image_file.get(item_id, "")
            path = self._image_path_for_file(image_file)
            return {
                "image_path": path,
                "image_file": image_file,
                "display_chip_id": item_id,
                "box": None,
            } if path else None

        pre = self.stage_display_meta.get(stage, {}).get(item_id)
        if pre:
            image_file = str(pre.get("base_image_file") or "")
            path = self._image_path_for_file(image_file)
            vals = [pre.get(k) for k in ("box_left_pct", "box_top_pct", "box_width_pct", "box_height_pct")]
            if path and all(v is not None for v in vals):
                return {
                    "image_path": path,
                    "image_file": image_file,
                    "display_chip_id": str(pre.get("display_chip_id") or ""),
                    "box": tuple(float(v) for v in vals),
                }

        chip = self._choose_display_chip(item_id)
        image_file = self.chip_image_file.get(str(chip), "")
        path = self._image_path_for_file(image_file)
        geom = self._prediction_geometry_in_grid_crs(item_id)
        grid_feat = self.grid_feature_by_chip.get(str(chip))
        if not path or geom is None or grid_feat is None:
            return None
        box = self._bbox_percent(geom.boundingBox(), grid_feat.geometry().boundingBox())
        return {
            "image_path": path,
            "image_file": image_file,
            "display_chip_id": str(chip),
            "box": box,
        }

    @staticmethod
    def _row_order_candidate_ids(expected_ids, n_features):
        """
        Reproduce the original Shiny preparation rule.  When candidate_id was
        absent, predictions$candidate_id <- seq_len(nrow(predictions)).

        The mapping CSV is used as a safety check so we never silently attach
        a different ID system to an already-annotated database.
        """
        expected = [str(x).strip() for x in expected_ids]
        if len(expected) != n_features:
            raise RuntimeError(
                "Cannot reconstruct candidate IDs safely: the prediction layer has "
                f"{n_features:,} feature(s), but object_chip_map.csv contains "
                f"{len(expected):,} unique candidate ID(s)."
            )

        sequential = [str(i) for i in range(1, n_features + 1)]
        if set(expected) == set(sequential):
            return sequential

        # Older/non-standard preparations may use non-numeric IDs. If every
        # prediction has exactly one unique mapped ID, preserve first appearance
        # in object_chip_map.csv rather than inventing new values.
        return expected

    def _make_prediction_working_copy(self, source_layer, candidate_ids):
        """Create a persistent GeoPackage copy with a full candidate_id field."""
        features = list(source_layer.getFeatures())
        if len(features) != len(candidate_ids):
            raise RuntimeError(
                "Internal candidate-ID assignment error: prediction feature count "
                "does not match the reconstructed ID count."
            )

        geom_name = QgsWkbTypes.displayString(source_layer.wkbType())
        crs = source_layer.crs().authid()
        mem = QgsVectorLayer(f"{geom_name}?crs={crs}", "Waste predictions", "memory")
        provider = mem.dataProvider()
        provider.addAttributes(list(source_layer.fields()) + [QgsField("candidate_id", QVariant.String)])
        mem.updateFields()

        out = []
        for feature, cid in zip(features, candidate_ids):
            nf = QgsFeature(mem.fields())
            nf.setGeometry(feature.geometry())
            nf.setAttributes(list(feature.attributes()) + [str(cid)])
            out.append(nf)
        provider.addFeatures(out)
        mem.updateExtents()

        output_dir = self.config.get("output_dir") or os.path.dirname(self.config["predictions"])
        os.makedirs(output_dir, exist_ok=True)
        gpkg = os.path.join(output_dir, "waste_predictions_with_candidate_id.gpkg")
        layer_name = "waste_predictions"

        options = QgsVectorFileWriter.SaveVectorOptions()
        options.driverName = "GPKG"
        options.layerName = layer_name
        options.actionOnExistingFile = QgsVectorFileWriter.CreateOrOverwriteFile
        result = QgsVectorFileWriter.writeAsVectorFormatV3(
            mem, gpkg, QgsProject.instance().transformContext(), options
        )
        if result[0] != QgsVectorFileWriter.NoError:
            raise RuntimeError(
                "The prediction layer has no candidate_id field and QGIS could not "
                f"create the working GeoPackage: {result}"
            )

        # The working GeoPackage contains a single layer, so storing the plain
        # file path keeps project reopening compatible with QFileDialog/os.path.
        layer = self._vector_layer(gpkg, "Waste predictions")
        self.config["predictions"] = gpkg
        self.generated_prediction_copy = gpkg
        return layer

    def _ensure_candidate_ids(self, layer, expected_ids):
        idx = layer.fields().indexFromName("candidate_id")
        if idx < 0:
            feature_count = int(layer.featureCount())
            candidate_ids = self._row_order_candidate_ids(expected_ids, feature_count)
            return self._make_prediction_working_copy(layer, candidate_ids)

        values = [str(f["candidate_id"]).strip() for f in layer.getFeatures()]
        if any(not x for x in values):
            raise RuntimeError("Prediction layer contains blank candidate_id values.")
        if len(values) != len(set(values)):
            raise RuntimeError("Prediction layer candidate_id values are not unique.")

        expected = set(str(x) for x in expected_ids)
        actual = set(values)
        if expected != actual:
            missing = sorted(expected - actual, key=self._candidate_sort_key)[:10]
            extra = sorted(actual - expected, key=self._candidate_sort_key)[:10]
            details = []
            if missing:
                details.append("missing from predictions: " + ", ".join(missing))
            if extra:
                details.append("not present in object_chip_map.csv: " + ", ".join(extra))
            raise RuntimeError(
                "candidate_id values in the prediction layer do not match object_chip_map.csv ("
                + "; ".join(details) + ")."
            )
        return layer

    def load(self):
        self.generated_prediction_copy = None
        expected_candidate_ids = self._read_object_chip_map()
        self._read_chip_metadata()
        self._read_prepared_display_metadata(2)
        self._read_prepared_display_metadata(3)

        self.grid_layer = self._vector_layer(self.config["review_grid"], "Waste review grid")
        source_pred_layer = self._vector_layer(self.config["predictions"], "Waste predictions")

        if self.grid_layer.fields().indexFromName("chip_id") < 0:
            raise RuntimeError("Review grid must contain a chip_id field.")

        self.pred_layer = self._ensure_candidate_ids(source_pred_layer, expected_candidate_ids)

        self.distance_area.setSourceCrs(
            self.pred_layer.crs(), QgsProject.instance().transformContext()
        )
        ellipsoid = QgsProject.instance().ellipsoid()
        if ellipsoid:
            self.distance_area.setEllipsoid(ellipsoid)

        self.grid_feature_by_chip = {
            str(f["chip_id"]): f for f in self.grid_layer.getFeatures()
        }
        self.refresh_prediction_cache()
        self.refresh_stage1_status()

    def refresh_prediction_cache(self):
        self.pred_feature_by_candidate = {
            str(f["candidate_id"]): f for f in self.pred_layer.getFeatures()
        }
        self.pred_area_m2 = {}
        for cid, feat in self.pred_feature_by_candidate.items():
            geom = feat.geometry()
            try:
                area = float(self.distance_area.measureArea(geom))
            except Exception:
                area = float(geom.area())
            self.pred_area_m2[cid] = area

    @property
    def min_area(self):
        return float(self.config.get("min_area_m2", 0.25))

    def stage1_items(self):
        return list(self.grid_feature_by_chip.keys())

    @staticmethod
    def classify_stage1_statuses(statuses):
        x = sorted(set(str(v) for v in statuses))
        if "unreviewed" in x:
            return "pending"
        if any(v in {"mixed", "not_sure"} for v in x):
            return "second_review"
        if x and all(v == "waste" for v in x):
            return "retained"
        if x and all(v == "not_waste" for v in x):
            return "rejected"
        return "second_review"

    def _refresh_one_stage1_candidate(self, cid, s1):
        cid = str(cid)
        chips = self.object_chip_map.get(cid, [])
        statuses = [s1.get(ch, {"label": "unreviewed"})["label"] for ch in chips]
        if not statuses:
            self.stage1_status[cid] = "pending"
            self.stage1_reason[cid] = "not_mapped_to_review_grid"
            self.representative_chip[cid] = None
            return
        self.stage1_status[cid] = self.classify_stage1_statuses(statuses)
        self.stage1_reason[cid] = " + ".join(sorted(set(statuses)))
        ambiguous = [
            ch for ch in chips
            if s1.get(ch, {"label": "unreviewed"})["label"] in {"mixed", "not_sure"}
        ]
        self.representative_chip[cid] = ambiguous[0] if ambiguous else chips[0]

    def refresh_stage1_status(self):
        s1 = self.db.current(1)
        self.stage1_status = {}
        self.stage1_reason = {}
        self.representative_chip = {}
        for cid in self.pred_feature_by_candidate:
            self._refresh_one_stage1_candidate(cid, s1)

    def refresh_stage1_for_chip(self, chip_id):
        """Refresh only candidate routing affected by one Stage-1 cell."""
        chip_id = str(chip_id)
        s1 = self.db.current(1)
        for cid in self.chip_to_candidates.get(chip_id, []):
            self._refresh_one_stage1_candidate(cid, s1)

    def prepare_stage2(self):
        s1 = self.db.current(1)
        missing = [ch for ch in self.stage1_items() if ch not in s1]
        if missing:
            raise RuntimeError(f"Stage 1 is not complete. {len(missing)} location(s) remain.")
        self.refresh_stage1_status()
        ids = [
            cid for cid in self.pred_feature_by_candidate
            if self.stage1_status.get(cid) == "second_review"
            and self.pred_area_m2.get(cid, 0) >= self.min_area
            and self.representative_chip.get(cid)
        ]
        eligible = set(ids)
        prepared_order = [cid for cid in self.stage_display_order.get(2, []) if cid in eligible]
        missing_from_prepared = sorted(eligible - set(prepared_order), key=self._candidate_sort_key)
        ids = prepared_order + missing_from_prepared if prepared_order else sorted(ids, key=self._candidate_sort_key)
        self.stage2_ids = ids
        return ids

    def prepare_stage3(self):
        if not self.stage2_ids:
            self.prepare_stage2()
        s2 = self.db.current(2)
        unreviewed = [cid for cid in self.stage2_ids if cid not in s2]
        unsure = [cid for cid in self.stage2_ids if s2.get(cid, {}).get("label") == "not_sure"]
        if unreviewed or unsure:
            raise RuntimeError(
                f"Stage 2 must be fully resolved before Stage 3. {len(unreviewed)} unreviewed and {len(unsure)} marked Not sure."
            )

        s1_positive = [
            cid for cid in self.pred_feature_by_candidate
            if self.pred_area_m2.get(cid, 0) >= self.min_area
            and self.stage1_status.get(cid) == "retained"
        ]
        s2_positive = [cid for cid in self.stage2_ids if s2[cid]["label"] == "waste"]
        ids = []
        self.review_source = {}
        for cid in s1_positive:
            if cid not in ids:
                ids.append(cid)
                self.review_source[cid] = "stage1"
        for cid in s2_positive:
            if cid not in ids:
                ids.append(cid)
                self.review_source[cid] = "stage2"
        eligible = set(ids)
        prepared_order = [cid for cid in self.stage_display_order.get(3, []) if cid in eligible]
        missing_from_prepared = sorted(eligible - set(prepared_order), key=self._candidate_sort_key)
        ids = prepared_order + missing_from_prepared if prepared_order else sorted(ids, key=self._candidate_sort_key)
        self.stage3_ids = ids
        return ids

    @staticmethod
    def _candidate_sort_key(cid):
        try:
            return (0, int(cid))
        except Exception:
            return (1, str(cid))

    def feature_for(self, stage, item_id):
        if int(stage) == 1:
            return self.grid_feature_by_chip.get(str(item_id)), self.grid_layer
        return self.pred_feature_by_candidate.get(str(item_id)), self.pred_layer

    def active_ids(self, stage):
        if int(stage) == 1:
            return self.stage1_items()
        if int(stage) == 2:
            if not self.stage2_ids:
                return self.prepare_stage2()
            return self.stage2_ids
        if not self.stage3_ids:
            return self.prepare_stage3()
        return self.stage3_ids

    def next_unreviewed(self, stage, after=None, include_not_sure=False):
        ids = self.active_ids(stage)
        current = self.db.current(stage)
        start = 0
        if after is not None and str(after) in ids:
            start = ids.index(str(after)) + 1
        order = ids[start:] + ids[:start]
        for item_id in order:
            row = current.get(str(item_id))
            if row is None or (include_not_sure and row["label"] == "not_sure"):
                return str(item_id)
        return None

    def stage_progress(self, stage):
        ids = self.active_ids(stage)
        current = self.db.current(stage)
        reviewed = sum(1 for x in ids if str(x) in current)
        return reviewed, len(ids), self.db.counts(stage, ids)
