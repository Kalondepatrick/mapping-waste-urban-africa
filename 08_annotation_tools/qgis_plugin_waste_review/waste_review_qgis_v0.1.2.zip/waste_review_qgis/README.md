# Waste Review — QGIS plugin (v0.1.0)

Native QGIS implementation of the three-stage waste-prediction review workflow previously implemented in Shiny.

## What this build implements

- **Stage 1 — 50 m location review**
  - Waste
  - Not waste
  - Waste + false positives
  - Not sure
- **Stage 2 — object review**
  - Objects are routed here using the same cross-cell decision logic as the Shiny app.
  - Minimum object area defaults to **0.25 m²**.
  - Waste / Not waste / Not sure.
- **Stage 3 — final positive audit**
  - All Stage-1 retained objects and Stage-2 Waste objects enter the final audit.
  - Keep / Delete / Needs edit / Not sure.
  - `Start geometry edit` selects the current prediction and places the prediction layer in QGIS edit mode.
- Existing/current review decisions plus full history stored in SQLite.
- Claim tables and a 30-minute expiry protect against two reviewers opening the same item at the same time.
- Keyboard shortcuts: `1`, `2`, `3`, `4`, and `S` to skip.
- Map-canvas navigation, selection and highlighting.
- GeoPackage + CSV audit exports.
- Connected/intersecting final objects are combined into contiguous waste-pile units for final pile counts.

## Required inputs

1. `review_grid.gpkg` (or another vector format) with a **chip_id** field.
2. Prediction polygon layer such as `waste_piles.shp` with a **candidate_id** field.
3. `object_chip_map.csv` with:
   - `candidate_id`
   - `chip_id`
4. `review_log.sqlite` — select the existing Shiny database to continue your reviews, or choose a new filename to create a fresh database.
5. Export folder.

The orthomosaic does **not** need to be configured in the plugin. Load your monthly/appropriate imagery in the QGIS project normally. The plugin navigates the QGIS map canvas to the current grid cell or prediction object, so whichever imagery is visible provides the review context.

## Install

The distributed ZIP should contain a top-level folder named `waste_review_qgis`.

In QGIS:

1. **Plugins → Manage and Install Plugins…**
2. **Install from ZIP**
3. Select `waste_review_qgis.zip`.
4. Enable **Waste Review** if QGIS does not enable it automatically.
5. Open it from **Vector → Waste Review** or the toolbar button.

## Recommended first test

Make a copy of your current `review_log.sqlite` and use the copy for the first test. Load the orthomosaic in QGIS, start the plugin, point it at the copied database and the existing project inputs, then verify 5–10 already reviewed Stage-1 cells against the old Shiny app before continuing new classifications.

## Stage-1 routing logic retained from the Shiny app

For each candidate prediction, all grid cells linked to that candidate in `object_chip_map.csv` are considered:

- any unreviewed cell → `pending`
- any `mixed` or `not_sure` cell → Stage 2
- all `waste` → retained
- all `not_waste` → rejected
- conflicting `waste` + `not_waste` → Stage 2

## Important v0.1 notes

- This is the first native-QGIS implementation and should initially be tested on a **copy** of the SQLite database and prediction dataset.
- If you physically edit a Stage-3 prediction geometry, save/commit QGIS layer edits before exporting.
- The plugin assumes `candidate_id` values in the prediction layer exactly match `candidate_id` in `object_chip_map.csv`.
- For multi-user reviewing on separate computers, a centrally hosted PostgreSQL/PostGIS review database would be preferable to a SQLite file on a network share. SQLite remains appropriate for single-computer use and is retained for compatibility with the current workflow.

## QGIS compatibility

Version 0.1.1 fixes QGIS 3.34 LTR compatibility by importing `QgsHighlight` from `qgis.gui`. The plugin is intended for QGIS 3.28+ and has been adjusted specifically for QGIS 3.34.7-Prizren based on the reported traceback.

## Authors

Patrick Ken Kalonde and OpenAI
