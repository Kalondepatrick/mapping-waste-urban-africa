import csv
import os
from collections import defaultdict, deque

from qgis.PyQt.QtCore import QVariant
from qgis.core import (
    QgsFeature,
    QgsField,
    QgsFields,
    QgsGeometry,
    QgsProject,
    QgsVectorFileWriter,
    QgsVectorLayer,
    QgsWkbTypes,
)


class ExportEngine:
    def __init__(self, engine, db):
        self.engine = engine
        self.db = db

    def _memory_subset(self, source, features, name, extra_fields=None, extra_values=None):
        geom_name = QgsWkbTypes.displayString(source.wkbType())
        crs = source.crs().authid()
        layer = QgsVectorLayer(f"{geom_name}?crs={crs}", name, "memory")
        provider = layer.dataProvider()
        fields = list(source.fields())
        for fld in extra_fields or []:
            fields.append(fld)
        provider.addAttributes(fields)
        layer.updateFields()
        output = []
        for f in features:
            nf = QgsFeature(layer.fields())
            nf.setGeometry(f.geometry())
            attrs = list(f.attributes())
            vals = (extra_values or {}).get(str(f["candidate_id"]), []) if "candidate_id" in f.fields().names() else []
            nf.setAttributes(attrs + list(vals))
            output.append(nf)
        provider.addFeatures(output)
        layer.updateExtents()
        return layer

    def _write_layer(self, layer, gpkg, layer_name, first=False):
        options = QgsVectorFileWriter.SaveVectorOptions()
        options.driverName = "GPKG"
        options.layerName = layer_name
        if first:
            options.actionOnExistingFile = QgsVectorFileWriter.CreateOrOverwriteFile
        else:
            options.actionOnExistingFile = QgsVectorFileWriter.CreateOrOverwriteLayer
        result = QgsVectorFileWriter.writeAsVectorFormatV3(
            layer, gpkg, QgsProject.instance().transformContext(), options
        )
        if result[0] != QgsVectorFileWriter.NoError:
            raise RuntimeError(f"Failed writing {layer_name}: {result}")

    def _csv(self, path, rows, fieldnames):
        with open(path, "w", newline="", encoding="utf-8") as fh:
            writer = csv.DictWriter(fh, fieldnames=fieldnames)
            writer.writeheader()
            for row in rows:
                writer.writerow({k: row.get(k, "") for k in fieldnames})

    def _connected_units(self, final_ids, sources):
        feats = self.engine.pred_feature_by_candidate
        ids = [cid for cid in final_ids if cid in feats]
        if not ids:
            return []
        adjacency = defaultdict(set)
        # For a few thousand objects, pairwise bounding-box pruning through a spatial index is preferred.
        from qgis.core import QgsSpatialIndex
        index = QgsSpatialIndex()
        id_by_fid = {}
        temp_feats = []
        for i, cid in enumerate(ids):
            f = QgsFeature()
            f.setId(i)
            f.setGeometry(feats[cid].geometry())
            temp_feats.append(f)
            id_by_fid[i] = cid
            index.addFeature(f)
        for i, cid in enumerate(ids):
            g = feats[cid].geometry()
            for j in index.intersects(g.boundingBox()):
                if j == i:
                    continue
                other = id_by_fid[j]
                if g.intersects(feats[other].geometry()):
                    adjacency[cid].add(other)
                    adjacency[other].add(cid)
        seen = set()
        units = []
        for cid in ids:
            if cid in seen:
                continue
            q = deque([cid])
            seen.add(cid)
            comp = []
            while q:
                cur = q.popleft()
                comp.append(cur)
                for nb in adjacency[cur]:
                    if nb not in seen:
                        seen.add(nb)
                        q.append(nb)
            geoms = [feats[x].geometry() for x in comp]
            union = QgsGeometry.unaryUnion(geoms)
            srcs = {sources.get(x, "") for x in comp}
            src = "both" if {"stage1", "stage2"}.issubset(srcs) else next(iter(srcs))
            units.append((comp, union, src))
        return units

    def export(self, output_dir):
        os.makedirs(output_dir, exist_ok=True)
        # Re-read prediction geometries so Stage-3 edits committed in QGIS are exported.
        self.engine.refresh_prediction_cache()
        self.engine.refresh_stage1_status()
        try:
            stage2_ids = self.engine.prepare_stage2()
        except RuntimeError:
            stage2_ids = [
                cid for cid in self.engine.pred_feature_by_candidate
                if self.engine.stage1_status.get(cid) == "second_review"
                and self.engine.pred_area_m2.get(cid, 0) >= self.engine.min_area
            ]
        s1 = self.db.current(1)
        s2 = self.db.current(2)
        s3 = self.db.current(3)

        eligible = {
            cid for cid, area in self.engine.pred_area_m2.items() if area >= self.engine.min_area
        }
        stage1_retained = {
            cid for cid in eligible if self.engine.stage1_status.get(cid) == "retained"
        }
        stage1_rejected = {
            cid for cid in eligible if self.engine.stage1_status.get(cid) == "rejected"
        }
        stage2_waste = {cid for cid in stage2_ids if s2.get(cid, {}).get("label") == "waste"}
        stage2_rejected = {cid for cid in stage2_ids if s2.get(cid, {}).get("label") == "not_waste"}
        stage2_unresolved = {
            cid for cid in stage2_ids if cid not in s2 or s2[cid]["label"] == "not_sure"
        }

        pre_stage3 = stage1_retained | stage2_waste
        sources = {cid: "stage1" for cid in stage1_retained}
        sources.update({cid: "stage2" for cid in stage2_waste if cid not in sources})
        final_keep = {cid for cid in pre_stage3 if s3.get(cid, {}).get("label") == "keep"}
        stage3_delete = {cid for cid in pre_stage3 if s3.get(cid, {}).get("label") == "delete"}
        stage3_edit = {cid for cid in pre_stage3 if s3.get(cid, {}).get("label") == "needs_edit"}
        stage3_unresolved = {
            cid for cid in pre_stage3 if cid not in s3 or s3[cid]["label"] == "not_sure"
        }
        final_rejected = stage1_rejected | stage2_rejected
        pending = {
            cid for cid in eligible if self.engine.stage1_status.get(cid) == "pending"
        }
        final_unresolved = pending | stage2_unresolved | stage3_edit | stage3_unresolved
        below_min = set(self.engine.pred_feature_by_candidate) - eligible

        pred = self.engine.pred_feature_by_candidate
        def fs(ids):
            return [pred[cid] for cid in ids if cid in pred]

        gpkg = os.path.join(output_dir, "waste_review_export.gpkg")
        if os.path.exists(gpkg):
            os.remove(gpkg)

        layers = []
        # Prediction-level export layers.
        layers.append(("stage1_retained_predictions", fs(stage1_retained)))
        layers.append(("stage1_second_review_predictions", fs(set(stage2_ids))))
        layers.append(("stage1_rejected_predictions", fs(stage1_rejected)))
        layers.append(("second_review_waste", fs(stage2_waste)))
        layers.append(("second_review_rejected", fs(stage2_rejected)))
        layers.append(("second_review_unresolved", fs(stage2_unresolved)))
        layers.append(("stage3_candidates", fs(pre_stage3)))
        layers.append(("stage3_keep", fs(final_keep)))
        layers.append(("stage3_delete", fs(stage3_delete)))
        layers.append(("stage3_needs_edit", fs(stage3_edit)))
        layers.append(("stage3_unresolved", fs(stage3_unresolved)))
        layers.append(("final_verified_waste", fs(final_keep)))
        layers.append(("final_rejected_predictions", fs(final_rejected)))
        layers.append(("final_unresolved_predictions", fs(final_unresolved)))
        layers.append(("below_min_area_predictions", fs(below_min)))

        first = True
        for name, features in layers:
            if not features:
                continue
            extra_fields = [
                QgsField("review_src", QVariant.String),
                QgsField("s1_class", QVariant.String),
                QgsField("s1_reason", QVariant.String),
                QgsField("s2_label", QVariant.String),
                QgsField("s3_label", QVariant.String),
            ]
            values = {}
            for f in features:
                cid = str(f["candidate_id"])
                values[cid] = [
                    sources.get(cid, ""),
                    self.engine.stage1_status.get(cid, ""),
                    self.engine.stage1_reason.get(cid, ""),
                    s2.get(cid, {}).get("label", ""),
                    s3.get(cid, {}).get("label", ""),
                ]
            mem = self._memory_subset(self.engine.pred_layer, features, name, extra_fields, values)
            self._write_layer(mem, gpkg, name, first=first)
            first = False

        # Reviewed grid layer.
        grid_extra = [
            QgsField("review_cls", QVariant.String),
            QgsField("reviewer", QVariant.String),
            QgsField("reviewed_at", QVariant.String),
        ]
        grid_vals = {}
        for f in self.engine.grid_layer.getFeatures():
            chip = str(f["chip_id"])
            row = s1.get(chip, {})
            grid_vals[chip] = [row.get("label", "unreviewed"), row.get("annotator", ""), row.get("timestamp", "")]
        # custom grid copy because key is chip_id, not candidate_id
        grid_mem = QgsVectorLayer(
            f"{QgsWkbTypes.displayString(self.engine.grid_layer.wkbType())}?crs={self.engine.grid_layer.crs().authid()}",
            "reviewed_grid", "memory"
        )
        gp = grid_mem.dataProvider()
        gp.addAttributes(list(self.engine.grid_layer.fields()) + grid_extra)
        grid_mem.updateFields()
        gout = []
        for f in self.engine.grid_layer.getFeatures():
            nf = QgsFeature(grid_mem.fields())
            nf.setGeometry(f.geometry())
            nf.setAttributes(list(f.attributes()) + grid_vals[str(f["chip_id"])])
            gout.append(nf)
        gp.addFeatures(gout)
        grid_mem.updateExtents()
        self._write_layer(grid_mem, gpkg, "reviewed_grid", first=first)
        first = False

        # Contiguous final waste units.
        units = self._connected_units(final_keep, sources)
        if units:
            geom_name = QgsWkbTypes.displayString(self.engine.pred_layer.wkbType())
            unit_layer = QgsVectorLayer(
                f"{geom_name}?crs={self.engine.pred_layer.crs().authid()}",
                "final_verified_waste_units", "memory"
            )
            up = unit_layer.dataProvider()
            up.addAttributes([
                QgsField("waste_id", QVariant.String),
                QgsField("source", QVariant.String),
                QgsField("n_parts", QVariant.Int),
                QgsField("n_s1", QVariant.Int),
                QgsField("n_s2", QVariant.Int),
                QgsField("area_m2", QVariant.Double),
            ])
            unit_layer.updateFields()
            ufeats = []
            for i, (comp, geom, src) in enumerate(units, 1):
                f = QgsFeature(unit_layer.fields())
                f.setGeometry(geom)
                try:
                    area = float(self.engine.distance_area.measureArea(geom))
                except Exception:
                    area = float(geom.area())
                f.setAttributes([
                    f"W{i:06d}", src, len(comp),
                    sum(1 for c in comp if sources.get(c) == "stage1"),
                    sum(1 for c in comp if sources.get(c) == "stage2"),
                    area,
                ])
                ufeats.append(f)
            up.addFeatures(ufeats)
            unit_layer.updateExtents()
            self._write_layer(unit_layer, gpkg, "final_verified_waste_units", first=first)

        # CSV audit tables.
        first_rows = []
        for chip in self.engine.stage1_items():
            row = s1.get(chip, {})
            first_rows.append({
                "chip_id": chip,
                "label": row.get("label", "unreviewed"),
                "annotator": row.get("annotator", ""),
                "notes": row.get("notes", ""),
                "timestamp": row.get("timestamp", ""),
            })
        self._csv(os.path.join(output_dir, "first_review_results.csv"), first_rows,
                  ["chip_id", "label", "annotator", "notes", "timestamp"])

        second_rows = []
        for cid in stage2_ids:
            row = s2.get(cid, {})
            second_rows.append({
                "candidate_id": cid,
                "area_m2": self.engine.pred_area_m2.get(cid, 0),
                "stage1_reason": self.engine.stage1_reason.get(cid, ""),
                "representative_chip_id": self.engine.representative_chip.get(cid, ""),
                "second_label": row.get("label", "unreviewed"),
                "second_annotator": row.get("annotator", ""),
                "second_notes": row.get("notes", ""),
                "second_reviewed_at": row.get("timestamp", ""),
            })
        self._csv(os.path.join(output_dir, "second_review_results.csv"), second_rows,
                  ["candidate_id", "area_m2", "stage1_reason", "representative_chip_id", "second_label", "second_annotator", "second_notes", "second_reviewed_at"])

        third_rows = []
        for cid in sorted(pre_stage3, key=self.engine._candidate_sort_key):
            row = s3.get(cid, {})
            third_rows.append({
                "candidate_id": cid,
                "area_m2": self.engine.pred_area_m2.get(cid, 0),
                "review_src": sources.get(cid, ""),
                "stage1_class": self.engine.stage1_status.get(cid, ""),
                "stage1_reason": self.engine.stage1_reason.get(cid, ""),
                "second_label": s2.get(cid, {}).get("label", ""),
                "third_label": row.get("label", "unreviewed"),
                "third_annotator": row.get("annotator", ""),
                "third_notes": row.get("notes", ""),
                "third_reviewed_at": row.get("timestamp", ""),
            })
        self._csv(os.path.join(output_dir, "third_review_results.csv"), third_rows,
                  ["candidate_id", "area_m2", "review_src", "stage1_class", "stage1_reason", "second_label", "third_label", "third_annotator", "third_notes", "third_reviewed_at"])

        audit_rows = []
        for cid in self.engine.pred_feature_by_candidate:
            if cid in below_min:
                decision = "below_min_area"
            elif cid in stage1_rejected:
                decision = "rejected_stage1"
            elif cid in stage2_rejected:
                decision = "rejected_stage2"
            elif cid in stage2_unresolved:
                decision = "unresolved_stage2"
            elif cid in final_keep:
                decision = "final_keep_stage3"
            elif cid in stage3_delete:
                decision = "deleted_stage3"
            elif cid in stage3_edit:
                decision = "needs_edit_stage3"
            elif cid in stage3_unresolved:
                decision = "unresolved_stage3"
            elif self.engine.stage1_status.get(cid) == "pending":
                decision = "unresolved"
            elif cid in stage1_retained:
                decision = "retained_stage1"
            elif cid in stage2_waste:
                decision = "retained_stage2"
            else:
                decision = "unresolved"
            audit_rows.append({
                "candidate_id": cid,
                "area_m2": self.engine.pred_area_m2.get(cid, 0),
                "stage1_class": self.engine.stage1_status.get(cid, ""),
                "stage1_reason": self.engine.stage1_reason.get(cid, ""),
                "representative_chip_id": self.engine.representative_chip.get(cid, ""),
                "second_label": s2.get(cid, {}).get("label", ""),
                "third_label": s3.get(cid, {}).get("label", ""),
                "final_decision": decision,
            })
        self._csv(os.path.join(output_dir, "final_inventory_audit.csv"), audit_rows,
                  ["candidate_id", "area_m2", "stage1_class", "stage1_reason", "representative_chip_id", "second_label", "third_label", "final_decision"])

        summary = [
            {"measure": "total_first_review_locations", "value": len(self.engine.stage1_items())},
            {"measure": "raw_prediction_polygons", "value": len(self.engine.pred_feature_by_candidate)},
            {"measure": "predictions_below_min_area", "value": len(below_min)},
            {"measure": "active_second_review_candidates", "value": len(stage2_ids)},
            {"measure": "second_review_waste", "value": len(stage2_waste)},
            {"measure": "second_review_not_waste", "value": len(stage2_rejected)},
            {"measure": "second_review_unresolved", "value": len(stage2_unresolved)},
            {"measure": "stage3_candidate_objects", "value": len(pre_stage3)},
            {"measure": "stage3_kept_objects", "value": len(final_keep)},
            {"measure": "stage3_deleted_objects", "value": len(stage3_delete)},
            {"measure": "stage3_needs_edit_objects", "value": len(stage3_edit)},
            {"measure": "stage3_unresolved_objects", "value": len(stage3_unresolved)},
            {"measure": "final_verified_prediction_polygons", "value": len(final_keep)},
            {"measure": "final_rejected_prediction_polygons", "value": len(final_rejected)},
            {"measure": "final_unresolved_prediction_polygons", "value": len(final_unresolved)},
            {"measure": "final_contiguous_waste_piles", "value": len(units)},
        ]
        self._csv(os.path.join(output_dir, "review_export_summary.csv"), summary, ["measure", "value"])
        return {
            "gpkg": gpkg,
            "final_objects": len(final_keep),
            "final_units": len(units),
            "unresolved": len(final_unresolved),
        }
