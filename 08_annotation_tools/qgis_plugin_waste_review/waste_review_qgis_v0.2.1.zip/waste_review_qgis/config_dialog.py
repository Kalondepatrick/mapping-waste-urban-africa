import json
import os
import sqlite3

from qgis.PyQt.QtCore import QSettings
from qgis.PyQt.QtWidgets import (
    QComboBox, QDialog, QDialogButtonBox, QFileDialog, QFormLayout, QHBoxLayout,
    QLabel, QLineEdit, QMessageBox, QPushButton, QDoubleSpinBox, QVBoxLayout, QWidget
)


SETTINGS_PREFIX = "waste_review/"
PROJECT_META_KEYS = (
    "project_name",
    "review_grid",
    "predictions",
    "object_chip_map",
    "output_dir",
    "min_area_m2",
)


class PathRow(QWidget):
    def __init__(self, mode="file", filter_text="All files (*)", parent=None):
        super().__init__(parent)
        self.mode = mode
        self.filter_text = filter_text
        self.edit = QLineEdit()
        self.button = QPushButton("Browse…")
        self.button.clicked.connect(self.browse)
        lay = QHBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.addWidget(self.edit, 1)
        lay.addWidget(self.button)

    def browse(self):
        current = self.edit.text().strip() or os.path.expanduser("~")
        if self.mode == "dir":
            path = QFileDialog.getExistingDirectory(self, "Select folder", current)
        elif self.mode == "save":
            path, _ = QFileDialog.getSaveFileName(self, "Select file", current, self.filter_text)
        else:
            path, _ = QFileDialog.getOpenFileName(self, "Select file", current, self.filter_text)
        if path:
            self.edit.setText(path)

    def text(self):
        return self.edit.text().strip()

    def setText(self, value):
        self.edit.setText(value or "")


class ConfigDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Waste Review — Project setup")
        self.resize(820, 500)
        self.settings = QSettings()

        self.project_name = QLineEdit()
        self.reviewer = QLineEdit()
        self.grid = PathRow("file", "GeoPackage (*.gpkg);;Vector files (*.gpkg *.shp)")
        self.predictions = PathRow("file", "Vector files (*.shp *.gpkg)")
        self.mapping = PathRow("file", "CSV (*.csv)")
        self.database = PathRow("save", "SQLite (*.sqlite *.db)")
        self.output = PathRow("dir")
        self.min_area = QDoubleSpinBox()
        self.min_area.setDecimals(3)
        self.min_area.setRange(0.0, 1000000.0)
        self.min_area.setValue(0.25)
        self.min_area.setSuffix(" m²")

        intro = QLabel(
            "Start a new review project or reopen an existing one. Existing Shiny review databases are supported: "
            "select review_log.sqlite and the plugin will restore prior annotations and try to locate the associated "
            "review grid, prediction polygons, object_chip_map.csv and export folder automatically."
        )
        intro.setWordWrap(True)

        open_row = QHBoxLayout()
        self.load_existing_btn = QPushButton("Load existing project…")
        self.load_existing_btn.setToolTip("Select an existing review_log.sqlite or Waste Review project JSON file")
        self.load_existing_btn.clicked.connect(self.load_existing_project)
        open_row.addWidget(self.load_existing_btn)

        self.recent = QComboBox()
        self.recent.setMinimumWidth(320)
        self._populate_recent_projects()
        open_row.addWidget(QLabel("Recent:"))
        open_row.addWidget(self.recent, 1)
        self.open_recent_btn = QPushButton("Open recent")
        self.open_recent_btn.clicked.connect(self.open_recent_project)
        open_row.addWidget(self.open_recent_btn)

        self.project_status = QLabel("No existing project loaded.")
        self.project_status.setWordWrap(True)
        self.project_status.setStyleSheet("color: #555;")

        form = QFormLayout()
        form.addRow("Project name", self.project_name)
        form.addRow("Reviewer name", self.reviewer)
        form.addRow("Review grid", self.grid)
        form.addRow("Prediction polygons", self.predictions)
        form.addRow("object_chip_map.csv", self.mapping)
        form.addRow("review_log.sqlite", self.database)
        form.addRow("Export folder", self.output)
        form.addRow("Minimum object area", self.min_area)

        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)

        lay = QVBoxLayout(self)
        lay.addWidget(intro)
        lay.addLayout(open_row)
        lay.addWidget(self.project_status)
        lay.addLayout(form)
        lay.addWidget(buttons)
        self.load_settings()

    def _recent_databases(self):
        raw = self.settings.value(SETTINGS_PREFIX + "recent_databases", [])
        if raw is None:
            return []
        if isinstance(raw, str):
            raw = [raw]
        return [str(x) for x in raw if str(x).strip()]

    def _populate_recent_projects(self):
        self.recent.clear()
        valid = []
        for path in self._recent_databases():
            if os.path.isfile(path):
                valid.append(path)
                self.recent.addItem(f"{os.path.basename(os.path.dirname(path))} — {path}", path)
        self.open_recent_btn.setEnabled(bool(valid)) if hasattr(self, "open_recent_btn") else None

    def _remember_recent(self, database_path):
        if not database_path:
            return
        path = os.path.abspath(database_path)
        items = [x for x in self._recent_databases() if os.path.abspath(x) != path]
        items.insert(0, path)
        items = items[:12]
        self.settings.setValue(SETTINGS_PREFIX + "recent_databases", items)

    def load_settings(self):
        s = self.settings
        self.project_name.setText(s.value(SETTINGS_PREFIX + "project_name", ""))
        self.reviewer.setText(s.value(SETTINGS_PREFIX + "reviewer", ""))
        self.grid.setText(s.value(SETTINGS_PREFIX + "review_grid", ""))
        self.predictions.setText(s.value(SETTINGS_PREFIX + "predictions", ""))
        self.mapping.setText(s.value(SETTINGS_PREFIX + "object_chip_map", ""))
        self.database.setText(s.value(SETTINGS_PREFIX + "database", ""))
        self.output.setText(s.value(SETTINGS_PREFIX + "output_dir", ""))
        try:
            self.min_area.setValue(float(s.value(SETTINGS_PREFIX + "min_area_m2", 0.25)))
        except Exception:
            self.min_area.setValue(0.25)
        self._populate_recent_projects()

    def load_existing_project(self):
        start = self.database.text() or os.path.expanduser("~")
        path, _ = QFileDialog.getOpenFileName(
            self,
            "Load existing Waste Review project",
            start,
            "Waste Review projects (*.sqlite *.db *.json);;SQLite databases (*.sqlite *.db);;Project JSON (*.json);;All files (*)",
        )
        if path:
            self._load_project_path(path)

    def open_recent_project(self):
        path = self.recent.currentData()
        if path:
            self._load_project_path(str(path))

    def _load_project_path(self, path):
        try:
            if path.lower().endswith(".json"):
                self._load_project_json(path)
            else:
                self._load_project_database(path)
        except Exception as exc:
            QMessageBox.critical(self, "Load existing project", str(exc))

    def _load_project_json(self, path):
        with open(path, "r", encoding="utf-8") as fh:
            cfg = json.load(fh)
        base = os.path.dirname(os.path.abspath(path))
        for key in PROJECT_META_KEYS:
            value = cfg.get(key)
            if isinstance(value, str) and value and not os.path.isabs(value) and key != "project_name":
                value = os.path.normpath(os.path.join(base, value))
            cfg[key] = value
        db_path = cfg.get("database")
        if isinstance(db_path, str) and db_path and not os.path.isabs(db_path):
            db_path = os.path.normpath(os.path.join(base, db_path))
        if not db_path:
            raise RuntimeError("The project JSON does not contain a database path.")
        self._apply_project_config(cfg, db_path)
        self._set_database_summary(db_path, source="project file")

    def _read_database_metadata(self, db_path):
        with sqlite3.connect(db_path) as con:
            exists = con.execute(
                "SELECT 1 FROM sqlite_master WHERE type='table' AND name='project_metadata'"
            ).fetchone()
            if not exists:
                return {}
            rows = con.execute("SELECT key, value FROM project_metadata").fetchall()
        meta = {}
        for key, value in rows:
            try:
                meta[key] = json.loads(value)
            except Exception:
                meta[key] = value
        return meta

    def _table_count(self, con, table):
        exists = con.execute(
            "SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", (table,)
        ).fetchone()
        if not exists:
            return 0
        return int(con.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0])

    def _annotation_summary(self, db_path):
        with sqlite3.connect(db_path) as con:
            return {
                1: self._table_count(con, "annotations"),
                2: self._table_count(con, "second_review"),
                3: self._table_count(con, "third_review"),
            }

    @staticmethod
    def _first_existing(paths):
        for path in paths:
            if path and os.path.exists(path):
                return os.path.abspath(path)
        return ""

    def _infer_legacy_config(self, db_path):
        """Infer the original Shiny directory layout from review_log.sqlite."""
        db_path = os.path.abspath(db_path)
        app_dir = os.path.dirname(db_path)
        data_dir = os.path.join(app_dir, "data")
        # Original layout: BASE/05_finetuning/waste_review_app/review_log.sqlite
        base_dir = os.path.dirname(os.path.dirname(app_dir))

        grid = self._first_existing([
            os.path.join(data_dir, "review_grid.gpkg"),
            os.path.join(data_dir, "review_grid.shp"),
        ])
        mapping = self._first_existing([
            os.path.join(data_dir, "object_chip_map.csv"),
        ])
        predictions = self._first_existing([
            os.path.join(base_dir, "outputs", "waste_piles.shp"),
            os.path.join(base_dir, "outputs", "waste_piles.gpkg"),
            os.path.join(app_dir, "waste_piles.shp"),
            os.path.join(app_dir, "waste_piles.gpkg"),
        ])
        output = os.path.join(app_dir, "exports")

        project_name = os.path.basename(base_dir) if os.path.basename(base_dir) else os.path.basename(app_dir)
        return {
            "project_name": project_name,
            "review_grid": grid,
            "predictions": predictions,
            "object_chip_map": mapping,
            "output_dir": output,
            "min_area_m2": 0.25,
        }

    def _load_project_database(self, db_path):
        db_path = os.path.abspath(db_path)
        if not os.path.isfile(db_path):
            raise RuntimeError("The selected review database does not exist.")

        meta = self._read_database_metadata(db_path)
        inferred = self._infer_legacy_config(db_path)
        cfg = inferred.copy()
        for key in PROJECT_META_KEYS:
            value = meta.get(key)
            if value not in (None, ""):
                cfg[key] = value

        # If a project has been moved, prefer an existing inferred legacy path over a stale stored path.
        for key in ("review_grid", "predictions", "object_chip_map"):
            stored = cfg.get(key, "")
            if stored and os.path.exists(stored):
                continue
            if inferred.get(key) and os.path.exists(inferred[key]):
                cfg[key] = inferred[key]

        self._apply_project_config(cfg, db_path)
        self._remember_recent(db_path)
        self._populate_recent_projects()
        source = "saved QGIS project metadata" if meta else "legacy Shiny database"
        self._set_database_summary(db_path, source=source)

    def _apply_project_config(self, cfg, db_path):
        self.project_name.setText(str(cfg.get("project_name") or ""))
        self.database.setText(os.path.abspath(db_path))
        self.grid.setText(str(cfg.get("review_grid") or ""))
        self.predictions.setText(str(cfg.get("predictions") or ""))
        self.mapping.setText(str(cfg.get("object_chip_map") or ""))
        output = str(cfg.get("output_dir") or os.path.join(os.path.dirname(db_path), "exports"))
        self.output.setText(output)
        try:
            self.min_area.setValue(float(cfg.get("min_area_m2", 0.25)))
        except Exception:
            self.min_area.setValue(0.25)

    def _set_database_summary(self, db_path, source="database"):
        try:
            counts = self._annotation_summary(db_path)
            missing = []
            for label, path in (
                ("review grid", self.grid.text()),
                ("prediction polygons", self.predictions.text()),
                ("object_chip_map.csv", self.mapping.text()),
            ):
                if not path or not os.path.exists(path):
                    missing.append(label)
            text = (
                f"Loaded {source}: Stage 1 = {counts[1]:,} prior reviews; "
                f"Stage 2 = {counts[2]:,}; Stage 3 = {counts[3]:,}."
            )
            if missing:
                text += " Could not automatically locate: " + ", ".join(missing) + ". Select those files below."
            else:
                text += " All companion project files were located."
            self.project_status.setText(text)
        except Exception as exc:
            self.project_status.setText(f"Selected database, but its review summary could not be read: {exc}")

    def config(self):
        return {
            "project_name": self.project_name.text().strip(),
            "reviewer": self.reviewer.text().strip(),
            "review_grid": self.grid.text(),
            "predictions": self.predictions.text(),
            "object_chip_map": self.mapping.text(),
            "database": self.database.text(),
            "output_dir": self.output.text(),
            "min_area_m2": float(self.min_area.value()),
        }

    def validate(self):
        cfg = self.config()
        if not cfg["reviewer"]:
            return "Enter a reviewer name."
        for key, label in [
            ("review_grid", "review grid"),
            ("predictions", "prediction polygons"),
            ("object_chip_map", "object_chip_map.csv"),
        ]:
            if not cfg[key] or not os.path.isfile(cfg[key]):
                return f"Select a valid {label} file."
        if not cfg["database"]:
            return "Select a SQLite database path."
        parent = os.path.dirname(cfg["database"])
        if parent and not os.path.isdir(parent):
            return "The database folder does not exist."
        if not cfg["output_dir"]:
            return "Select an export folder."
        os.makedirs(cfg["output_dir"], exist_ok=True)
        return None

    def accept(self):
        error = self.validate()
        if error:
            QMessageBox.warning(self, "Waste Review", error)
            return
        cfg = self.config()
        s = self.settings
        for k, v in cfg.items():
            s.setValue(SETTINGS_PREFIX + k, v)
        self._remember_recent(cfg["database"])
        super().accept()
