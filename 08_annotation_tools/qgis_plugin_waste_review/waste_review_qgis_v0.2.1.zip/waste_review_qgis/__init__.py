def classFactory(iface):
    from .plugin import WasteReviewPlugin
    return WasteReviewPlugin(iface)
