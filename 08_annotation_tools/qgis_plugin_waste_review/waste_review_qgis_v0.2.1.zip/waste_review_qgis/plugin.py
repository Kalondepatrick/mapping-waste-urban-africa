from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtWidgets import QAction, QMessageBox

from .config_dialog import ConfigDialog
from .database import ReviewDatabase
from .dock import WasteReviewDock
from .review_engine import ReviewEngine


class WasteReviewPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.action = None
        self.dock = None

    def initGui(self):
        self.action = QAction("Waste Review", self.iface.mainWindow())
        self.action.setToolTip("Open the three-stage waste prediction review workflow")
        self.action.triggered.connect(self.run)
        self.iface.addPluginToVectorMenu("Waste Review", self.action)
        self.iface.addToolBarIcon(self.action)

    def unload(self):
        if self.dock:
            self.dock.close()
            self.iface.removeDockWidget(self.dock)
            self.dock = None
        if self.action:
            self.iface.removePluginVectorMenu("Waste Review", self.action)
            self.iface.removeToolBarIcon(self.action)
            self.action = None

    def run(self):
        if self.dock:
            self.dock.show()
            self.dock.raise_()
            return

        dlg = ConfigDialog(self.iface.mainWindow())
        if not dlg.exec_():
            return
        cfg = dlg.config()
        try:
            db = ReviewDatabase(cfg["database"])
            engine = ReviewEngine(cfg, db)
            if getattr(engine, "generated_prediction_copy", None):
                self.iface.messageBar().pushInfo(
                    "Waste Review",
                    "The prediction layer had no candidate_id field. A working GeoPackage "
                    "was created with IDs matched to object_chip_map.csv: "
                    + engine.generated_prediction_copy,
                    duration=12,
                )
            # Save project-level paths only after all input files have loaded successfully.
            # This makes the same review_log.sqlite sufficient to reopen the project later.
            db.save_project_config(cfg)
            self.dock = WasteReviewDock(self.iface, engine, db, cfg, self.iface.mainWindow())
            self.iface.addDockWidget(Qt.RightDockWidgetArea, self.dock)
            self.dock.show()
            self.dock.destroyed.connect(self._dock_destroyed)
        except Exception as e:
            QMessageBox.critical(self.iface.mainWindow(), "Waste Review", str(e))
            self.dock = None

    def _dock_destroyed(self, *args):
        self.dock = None
