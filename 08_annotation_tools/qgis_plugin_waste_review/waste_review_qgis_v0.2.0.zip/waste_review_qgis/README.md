# Waste Review QGIS Plugin

**Authors:** Patrick Ken Kalonde and OpenAI  
**Version:** 0.2.0

A native QGIS implementation of the three-stage waste-prediction review workflow originally developed as a Shiny application.

## Reopen an existing annotated project

Open **Vector → Waste Review**, then click **Load existing project…**.

You can select an existing `review_log.sqlite` directly. The plugin reads all existing Stage 1, Stage 2 and Stage 3 annotations from that database and continues from the saved progress.

For legacy Shiny projects it also tries to infer the original directory structure automatically:

- `data/review_grid.gpkg`
- `data/object_chip_map.csv`
- `../../outputs/waste_piles.shp`
- `exports/`

If the project has moved or one of those files cannot be found, the setup dialog leaves the missing field visible so you can browse to the new location without losing the annotations.

After a project has been opened successfully once with the QGIS plugin, its project paths are stored in a `project_metadata` table inside the same SQLite database. Thereafter selecting that `review_log.sqlite` restores the exact project paths automatically. The dialog also keeps a list of recent databases for quick reopening.

## Review workflow

### Stage 1 — 50 m location review

1. Waste
2. Not waste
3. Waste + false positives
4. Not sure

### Stage 2 — ambiguous object review

1. Waste
2. Not waste
3. Not sure

Objects smaller than the configured minimum mapping unit (default 0.25 m²) are not manually sent through Stage 2.

### Stage 3 — final positive audit

1. Keep
2. Delete
3. Needs edit
4. Not sure

The Stage-3 panel can put the prediction layer into QGIS edit mode so the selected object geometry can be corrected using the normal QGIS editing tools.

## Existing annotations

The plugin uses the original table names from the Shiny application:

- `annotations`, `annotation_history`, `claims`
- `second_review`, `second_review_history`, `second_claims`
- `third_review`, `third_review_history`, `third_claims`

Opening an old database does **not** delete or reset those tables. Existing decisions, notes, annotator names and history remain intact.

## Compatibility target

QGIS 3.34.7-Prizren LTR / Python 3.12, while retaining a minimum declared QGIS version of 3.28.
