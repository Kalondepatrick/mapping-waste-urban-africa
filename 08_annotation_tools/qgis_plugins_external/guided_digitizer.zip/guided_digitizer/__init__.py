def classFactory(iface):
    from .guided_digitizer import GuidedDigitizerPlugin
    return GuidedDigitizerPlugin(iface)
