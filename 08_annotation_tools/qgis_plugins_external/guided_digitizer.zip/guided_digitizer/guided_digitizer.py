from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtWidgets import (
    QAction,
    QDockWidget,
    QWidget,
    QVBoxLayout,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QGroupBox,
    QMessageBox,
)

from qgis.core import (
    QgsCoordinateTransform,
    QgsMapLayerProxyModel,
    QgsProject,
    QgsSettings,
    QgsVectorLayer,
    QgsWkbTypes,
)
from qgis.gui import QgsMapLayerComboBox


class GuidedDigitizerPlugin:
    """A small QGIS plugin for guided polygon-by-polygon digitization."""

    PLUGIN_MENU = "&Guided Digitizer"
    SETTINGS_ROOT = "guided_digitizer"

    def __init__(self, iface):
        self.iface = iface
        self.canvas = iface.mapCanvas()
        self.action = None
        self.toolbar = None
        self.dock = None

        self.nav_combo = None
        self.edit_combo = None
        self.progress_label = None
        self.fid_label = None
        self.previous_button = None
        self.next_button = None
        self.digitize_button = None
        self.vertex_button = None
        self.save_button = None
        self.reload_button = None

        self.nav_layer = None
        self.edit_layer = None
        self.feature_ids = []
        self.current_index = -1

    # ------------------------------------------------------------------
    # QGIS plugin lifecycle
    # ------------------------------------------------------------------
    def initGui(self):
        icon = QIcon.fromTheme("mActionCapturePolygon")
        self.action = QAction(icon, "Guided Digitizer", self.iface.mainWindow())
        self.action.setToolTip("Open Guided Digitizer")
        self.action.triggered.connect(self.show_dock)

        self.iface.addPluginToVectorMenu(self.PLUGIN_MENU, self.action)
        self.toolbar = self.iface.addToolBar("Guided Digitizer")
        self.toolbar.setObjectName("GuidedDigitizerToolbar")
        self.toolbar.addAction(self.action)

        self._create_dock()

    def unload(self):
        if self.dock is not None:
            self.iface.removeDockWidget(self.dock)
            self.dock.deleteLater()
            self.dock = None

        if self.action is not None:
            self.iface.removePluginVectorMenu(self.PLUGIN_MENU, self.action)

        if self.toolbar is not None:
            self.toolbar.deleteLater()
            self.toolbar = None

    # ------------------------------------------------------------------
    # UI
    # ------------------------------------------------------------------
    def _create_dock(self):
        self.dock = QDockWidget("Guided Digitizer", self.iface.mainWindow())
        self.dock.setObjectName("GuidedDigitizerDock")
        self.dock.setAllowedAreas(Qt.LeftDockWidgetArea | Qt.RightDockWidgetArea)

        root = QWidget()
        layout = QVBoxLayout(root)
        layout.setContentsMargins(8, 8, 8, 8)
        layout.setSpacing(8)

        intro = QLabel(
            "Choose the polygons to move through and the polygon layer you are digitizing into."
        )
        intro.setWordWrap(True)
        layout.addWidget(intro)

        layers_group = QGroupBox("Layers")
        layers_layout = QVBoxLayout(layers_group)

        layers_layout.addWidget(QLabel("Navigation polygons"))
        self.nav_combo = QgsMapLayerComboBox()
        self.nav_combo.setFilters(QgsMapLayerProxyModel.PolygonLayer)
        layers_layout.addWidget(self.nav_combo)

        layers_layout.addWidget(QLabel("Digitization polygons"))
        self.edit_combo = QgsMapLayerComboBox()
        self.edit_combo.setFilters(QgsMapLayerProxyModel.PolygonLayer)
        layers_layout.addWidget(self.edit_combo)

        self.reload_button = QPushButton("Load / Refresh polygons")
        self.reload_button.clicked.connect(self.reload_navigation)
        layers_layout.addWidget(self.reload_button)

        layout.addWidget(layers_group)

        nav_group = QGroupBox("Current navigation polygon")
        nav_layout = QVBoxLayout(nav_group)

        self.progress_label = QLabel("Object: — / —")
        self.progress_label.setAlignment(Qt.AlignCenter)
        font = self.progress_label.font()
        font.setBold(True)
        font.setPointSize(font.pointSize() + 2)
        self.progress_label.setFont(font)
        nav_layout.addWidget(self.progress_label)

        self.fid_label = QLabel("Feature ID: —")
        self.fid_label.setAlignment(Qt.AlignCenter)
        nav_layout.addWidget(self.fid_label)

        row = QHBoxLayout()
        self.previous_button = QPushButton("◀ Previous")
        self.next_button = QPushButton("Next ▶")
        self.previous_button.clicked.connect(self.previous_feature)
        self.next_button.clicked.connect(self.next_feature)
        row.addWidget(self.previous_button)
        row.addWidget(self.next_button)
        nav_layout.addLayout(row)

        layout.addWidget(nav_group)

        tools_group = QGroupBox("Digitizing")
        tools_layout = QVBoxLayout(tools_group)

        self.digitize_button = QPushButton("Digitize polygon")
        self.digitize_button.setToolTip(
            "Make the digitization layer active, start editing if needed, and activate Add Feature."
        )
        self.digitize_button.clicked.connect(self.start_digitizing)
        tools_layout.addWidget(self.digitize_button)

        self.vertex_button = QPushButton("Edit vertices")
        self.vertex_button.setToolTip(
            "Make the digitization layer active and activate QGIS's vertex editing tool."
        )
        self.vertex_button.clicked.connect(self.edit_vertices)
        tools_layout.addWidget(self.vertex_button)

        self.save_button = QPushButton("Save edits")
        self.save_button.clicked.connect(self.save_edits)
        tools_layout.addWidget(self.save_button)

        layout.addWidget(tools_group)
        layout.addStretch(1)

        self.nav_combo.layerChanged.connect(self._navigation_layer_changed)
        self.edit_combo.layerChanged.connect(self._edit_layer_changed)

        self.previous_button.setEnabled(False)
        self.next_button.setEnabled(False)

        self.dock.setWidget(root)
        self.iface.addDockWidget(Qt.RightDockWidgetArea, self.dock)

        # Initialize from whichever polygon layers QGIS currently exposes in the combos.
        self._navigation_layer_changed(self.nav_combo.currentLayer())
        self._edit_layer_changed(self.edit_combo.currentLayer())

        self.dock.hide()

    def show_dock(self):
        if self.dock is None:
            self._create_dock()
        self.dock.show()
        self.dock.raise_()

    # ------------------------------------------------------------------
    # Layer handling
    # ------------------------------------------------------------------
    def _navigation_layer_changed(self, layer):
        self.nav_layer = layer if isinstance(layer, QgsVectorLayer) else None
        self.reload_navigation()

    def _edit_layer_changed(self, layer):
        self.edit_layer = layer if isinstance(layer, QgsVectorLayer) else None

    def _is_polygon_layer(self, layer):
        return (
            isinstance(layer, QgsVectorLayer)
            and QgsWkbTypes.geometryType(layer.wkbType()) == QgsWkbTypes.PolygonGeometry
        )

    def reload_navigation(self):
        layer = self.nav_combo.currentLayer() if self.nav_combo is not None else None

        if not self._is_polygon_layer(layer):
            self.nav_layer = None
            self.feature_ids = []
            self.current_index = -1
            self._update_progress()
            return

        self.nav_layer = layer
        self.feature_ids = sorted(feature.id() for feature in layer.getFeatures())

        if not self.feature_ids:
            self.current_index = -1
            self._update_progress()
            self.iface.messageBar().pushWarning(
                "Guided Digitizer", "The navigation layer contains no polygons."
            )
            return

        saved_fid = self._saved_feature_id()
        if saved_fid in self.feature_ids:
            self.current_index = self.feature_ids.index(saved_fid)
        elif self.current_index < 0 or self.current_index >= len(self.feature_ids):
            self.current_index = 0

        self.go_to_current_feature()

    # ------------------------------------------------------------------
    # Navigation
    # ------------------------------------------------------------------
    def previous_feature(self):
        if not self.feature_ids:
            return
        if self.current_index > 0:
            self.current_index -= 1
            self.go_to_current_feature()

    def next_feature(self):
        if not self.feature_ids:
            return
        if self.current_index < len(self.feature_ids) - 1:
            self.current_index += 1
            self.go_to_current_feature()

    def go_to_current_feature(self):
        if (
            self.nav_layer is None
            or not self.feature_ids
            or self.current_index < 0
            or self.current_index >= len(self.feature_ids)
        ):
            self._update_progress()
            return

        fid = self.feature_ids[self.current_index]
        feature = self.nav_layer.getFeature(fid)
        if not feature.isValid() or feature.geometry().isEmpty():
            self.iface.messageBar().pushWarning(
                "Guided Digitizer", f"Navigation feature {fid} has no usable geometry."
            )
            return

        # Highlight the current navigation polygon without changing the active layer.
        self.nav_layer.selectByIds([fid])

        # Transform the feature extent into the map canvas CRS when needed.
        extent = feature.geometry().boundingBox()
        destination_crs = self.canvas.mapSettings().destinationCrs()
        if self.nav_layer.crs().isValid() and destination_crs.isValid():
            if self.nav_layer.crs() != destination_crs:
                transform = QgsCoordinateTransform(
                    self.nav_layer.crs(), destination_crs, QgsProject.instance()
                )
                extent = transform.transformBoundingBox(extent)

        # Give the annotator some imagery/context around the box.
        extent.scale(1.20)
        self.canvas.setExtent(extent)
        self.canvas.refresh()

        self._save_feature_id(fid)
        self._update_progress()

    def _update_progress(self):
        total = len(self.feature_ids)
        if total and 0 <= self.current_index < total:
            fid = self.feature_ids[self.current_index]
            self.progress_label.setText(f"Object: {self.current_index + 1} / {total}")
            self.fid_label.setText(f"Feature ID: {fid}")
            self.previous_button.setEnabled(self.current_index > 0)
            self.next_button.setEnabled(self.current_index < total - 1)
        else:
            self.progress_label.setText("Object: — / —")
            self.fid_label.setText("Feature ID: —")
            self.previous_button.setEnabled(False)
            self.next_button.setEnabled(False)

    # ------------------------------------------------------------------
    # Digitization controls
    # ------------------------------------------------------------------
    def _target_layer(self):
        layer = self.edit_combo.currentLayer() if self.edit_combo is not None else None
        if not self._is_polygon_layer(layer):
            QMessageBox.warning(
                self.iface.mainWindow(),
                "Guided Digitizer",
                "Choose a polygon digitization layer first.",
            )
            return None
        self.edit_layer = layer
        return layer

    def _prepare_target_for_editing(self):
        layer = self._target_layer()
        if layer is None:
            return None

        self.iface.setActiveLayer(layer)

        if not layer.isEditable():
            if not layer.startEditing():
                QMessageBox.warning(
                    self.iface.mainWindow(),
                    "Guided Digitizer",
                    "QGIS could not start editing on the selected digitization layer.",
                )
                return None

        return layer

    def start_digitizing(self):
        layer = self._prepare_target_for_editing()
        if layer is None:
            return

        # Use QGIS's native Add Feature map tool. On a polygon layer this captures polygons.
        self.iface.actionAddFeature().trigger()
        self.iface.messageBar().pushInfo(
            "Guided Digitizer", "Digitize the polygon in the current box."
        )

    def edit_vertices(self):
        layer = self._prepare_target_for_editing()
        if layer is None:
            return

        if hasattr(self.iface, "actionVertexToolActiveLayer"):
            self.iface.actionVertexToolActiveLayer().trigger()
        else:
            self.iface.actionVertexTool().trigger()

    def save_edits(self):
        layer = self._target_layer()
        if layer is None:
            return

        self.iface.setActiveLayer(layer)

        if not layer.isEditable():
            self.iface.messageBar().pushInfo(
                "Guided Digitizer", "There are no active edits to save."
            )
            return

        # Native QGIS save action keeps the normal QGIS editing workflow/behaviour.
        self.iface.actionSaveActiveLayerEdits().trigger()
        self.iface.messageBar().pushSuccess(
            "Guided Digitizer", "Edits saved."
        )

    # ------------------------------------------------------------------
    # Remember current location
    # ------------------------------------------------------------------
    def _settings_key(self):
        if self.nav_layer is None:
            return None
        project_name = QgsProject.instance().fileName() or "unsaved_project"
        return f"{self.SETTINGS_ROOT}/{project_name}/{self.nav_layer.id()}/last_fid"

    def _save_feature_id(self, fid):
        key = self._settings_key()
        if key:
            QgsSettings().setValue(key, int(fid))

    def _saved_feature_id(self):
        key = self._settings_key()
        if not key:
            return None
        value = QgsSettings().value(key, None)
        if value is None:
            return None
        try:
            return int(value)
        except (TypeError, ValueError):
            return None
