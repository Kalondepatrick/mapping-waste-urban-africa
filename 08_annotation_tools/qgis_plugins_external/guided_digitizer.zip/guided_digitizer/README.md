# Guided Digitizer — QGIS plugin

A deliberately small QGIS plugin for manual land-cover digitization over aerial imagery.

## What it does

- Choose a **Navigation polygons** layer: the boxes/polygons you want to visit one at a time.
- Choose a **Digitization polygons** layer: the Shapefile/GeoPackage layer where you draw annotations.
- **Previous / Next** selects and zooms to each navigation polygon in feature-ID order.
- **Digitize polygon** activates the target layer, starts editing if necessary, and activates QGIS's native Add Feature tool.
- **Edit vertices** activates QGIS's vertex editing tool for the target layer.
- **Save edits** uses QGIS's native save-edits action.
- The last visited navigation polygon is remembered for the project/layer.

The aerial imagery can remain loaded normally in the QGIS Layers panel underneath the vector layers.

## Install

### Option 1 — ZIP install

1. Keep the supplied `guided_digitizer.zip` file zipped.
2. In QGIS open **Plugins > Manage and Install Plugins**.
3. Choose **Install from ZIP**.
4. Select `guided_digitizer.zip`.
5. Enable **Guided Digitizer** if QGIS does not enable it automatically.

### Option 2 — manual install

Copy the `guided_digitizer` folder into your QGIS profile's `python/plugins` folder and restart QGIS.

## Use

1. Load your aerial image.
2. Load your boxes/navigation polygons.
3. Load or create your polygon digitization Shapefile/GeoPackage.
4. Open **Vector > Guided Digitizer > Guided Digitizer**, or click the toolbar icon.
5. Select the navigation layer and digitization layer.
6. Click **Load / Refresh polygons**.
7. Use **Previous** and **Next** to move through the boxes.
8. Click **Digitize polygon** and draw normally in QGIS.
9. Use **Edit vertices** when geometry needs correction.
10. Click **Save edits** regularly.

## Version

0.1.0 — initial working version.
