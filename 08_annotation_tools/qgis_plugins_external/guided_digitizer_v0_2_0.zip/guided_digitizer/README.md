# Guided Digitizer — QGIS plugin

Version 0.2.0 adds **Geo-SAM-assisted digitization** to the original polygon-navigation workflow.

## Core workflow

1. Load the aerial raster, target boxes/navigation polygons, and your annotation polygon layer.
2. Open **Guided Digitizer**.
3. Select:
   - **Navigation polygons** — boxes/polygons to visit one at a time.
   - **Aerial imagery / raster for SAM** — the image Geo-SAM should segment.
   - **Digitization polygons** — your real annotation Shapefile/GeoPackage.
4. Use **Previous / Next** to move through boxes.
5. For SAM-assisted annotation:
   - Click **SAM Select**.
   - Click the desired object in the map using Geo-SAM's foreground-point prompt.
   - Wait for the SAM polygon preview.
   - Click **Accept SAM** or **Accept + Next** in Guided Digitizer.
6. Guided Digitizer copies the current SAM polygon into your annotation layer and, by default, clips it to the current target box.
7. Use **Edit vertices** for corrections and **Save edits** regularly.

## Why Guided Digitizer does not use your annotation layer as Geo-SAM's output layer

Geo-SAM's native output layer requires its own SAM-specific fields (`group_ulid`, `N_GM`, `id`, `Area`, `N_FG`, `N_BG`, `BBox`). Guided Digitizer therefore leaves Geo-SAM's internal/temporary result layer alone, reads the current SAM prompt geometry, and copies that geometry into your selected annotation layer. This protects your own land-cover attribute schema.

## Optional class attribute

Choose a **Class field** and enter a **Class value** (for example `Vegetation`) before accepting a SAM result. Guided Digitizer will populate that field on the newly added feature. Leave the field as `(none)` if you only want geometry.

## Geo-SAM requirement

Install and enable the official **Geo SAM** QGIS plugin separately. In Geo-SAM Settings, install its required dependencies and download/configure a SAM model. Guided Digitizer does not bundle PyTorch or model checkpoints.

Geo-SAM 2.x is expected. The integration uses the current Geo-SAM selector interface and its live-encoding raster workflow.

## Controls

- **Previous / Next** — move between target polygons and zoom to the current one.
- **SAM Select** — open/configure Geo-SAM and activate a foreground-point prompt.
- **Accept SAM** — copy the current SAM prompt polygon to the annotation layer.
- **Accept + Next** — accept the polygon and immediately move to the next target box.
- **Clear SAM preview** — discard the current SAM prompt/preview.
- **Clip accepted SAM polygon to current target box** — hard spatial boundary; enabled by default.
- **Keep largest SAM component** — turns on Geo-SAM's Max Polygon Only mode.
- **Digitize polygon** — manual QGIS Add Feature fallback.
- **Edit vertices** — QGIS vertex editing.
- **Save edits** — save the annotation layer edits.

## Installation

Install `guided_digitizer_v0_2_0.zip` through:

**Plugins > Manage and Install Plugins > Install from ZIP**

Then enable **Guided Digitizer**.

## Important note

This package has been syntax-checked outside QGIS, but the actual Geo-SAM/QGIS interaction must be tested in your QGIS installation because plugin internals can differ between Geo-SAM releases.
