from qgis.PyQt.QtCore import Qt, QTimer
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtWidgets import (
    QAction,
    QCheckBox,
    QComboBox,
    QDockWidget,
    QGroupBox,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QMessageBox,
    QPushButton,
    QRadioButton,
    QVBoxLayout,
    QWidget,
)

from qgis.core import (
    QgsCoordinateTransform,
    QgsFeature,
    QgsGeometry,
    QgsMapLayerProxyModel,
    QgsProject,
    QgsSettings,
    QgsVectorLayer,
    QgsWkbTypes,
)
from qgis.gui import QgsMapLayerComboBox


class GuidedDigitizerPlugin:
    """Guided polygon-by-polygon digitization with optional Geo-SAM assistance."""

    PLUGIN_MENU = "&Guided Digitizer"
    SETTINGS_ROOT = "guided_digitizer"

    def __init__(self, iface):
        self.iface = iface
        self.canvas = iface.mapCanvas()
        self.action = None
        self.toolbar = None
        self.dock = None

        self.nav_combo = None
        self.raster_combo = None
        self.edit_combo = None
        self.class_field_combo = None
        self.class_value_edit = None
        self.progress_label = None
        self.fid_label = None
        self.sam_status_label = None

        self.previous_button = None
        self.next_button = None
        self.sam_button = None
        self.accept_sam_button = None
        self.accept_next_button = None
        self.clear_sam_button = None
        self.digitize_button = None
        self.vertex_button = None
        self.save_button = None
        self.reload_button = None

        self.clip_sam_checkbox = None
        self.keep_largest_checkbox = None

        self.nav_layer = None
        self.edit_layer = None
        self.feature_ids = []
        self.current_index = -1

    # ------------------------------------------------------------------
    # QGIS plugin lifecycle
    # ------------------------------------------------------------------
    def initGui(self):
        icon = QIcon.fromTheme("mActionCapturePolygon")
        self.action = QAction(icon, "Guided Digitizer", self.iface.mainWindow())
        self.action.setToolTip("Open Guided Digitizer")
        self.action.triggered.connect(self.show_dock)

        self.iface.addPluginToVectorMenu(self.PLUGIN_MENU, self.action)
        self.toolbar = self.iface.addToolBar("Guided Digitizer")
        self.toolbar.setObjectName("GuidedDigitizerToolbar")
        self.toolbar.addAction(self.action)

        self._create_dock()

    def unload(self):
        if self.dock is not None:
            self.iface.removeDockWidget(self.dock)
            self.dock.deleteLater()
            self.dock = None

        if self.action is not None:
            self.iface.removePluginVectorMenu(self.PLUGIN_MENU, self.action)

        if self.toolbar is not None:
            self.toolbar.deleteLater()
            self.toolbar = None

    # ------------------------------------------------------------------
    # UI
    # ------------------------------------------------------------------
    def _create_dock(self):
        self.dock = QDockWidget("Guided Digitizer", self.iface.mainWindow())
        self.dock.setObjectName("GuidedDigitizerDock")
        self.dock.setAllowedAreas(Qt.LeftDockWidgetArea | Qt.RightDockWidgetArea)

        root = QWidget()
        layout = QVBoxLayout(root)
        layout.setContentsMargins(8, 8, 8, 8)
        layout.setSpacing(8)

        intro = QLabel(
            "Move through target polygons, digitize manually, or use Geo-SAM to "
            "segment an object and copy the accepted polygon into your annotation layer."
        )
        intro.setWordWrap(True)
        layout.addWidget(intro)

        # Layers ---------------------------------------------------------
        layers_group = QGroupBox("Layers")
        layers_layout = QVBoxLayout(layers_group)

        layers_layout.addWidget(QLabel("Navigation polygons (target boxes)"))
        self.nav_combo = QgsMapLayerComboBox()
        self.nav_combo.setFilters(QgsMapLayerProxyModel.PolygonLayer)
        layers_layout.addWidget(self.nav_combo)

        layers_layout.addWidget(QLabel("Aerial imagery / raster for SAM"))
        self.raster_combo = QgsMapLayerComboBox()
        self.raster_combo.setFilters(QgsMapLayerProxyModel.RasterLayer)
        layers_layout.addWidget(self.raster_combo)

        layers_layout.addWidget(QLabel("Digitization polygons (your annotation layer)"))
        self.edit_combo = QgsMapLayerComboBox()
        self.edit_combo.setFilters(QgsMapLayerProxyModel.PolygonLayer)
        layers_layout.addWidget(self.edit_combo)

        self.reload_button = QPushButton("Load / Refresh polygons")
        self.reload_button.clicked.connect(self.reload_navigation)
        layers_layout.addWidget(self.reload_button)
        layout.addWidget(layers_group)

        # Optional attribute assignment ---------------------------------
        attr_group = QGroupBox("Annotation attributes (optional)")
        attr_layout = QVBoxLayout(attr_group)
        attr_layout.addWidget(QLabel("Class field"))
        self.class_field_combo = QComboBox()
        self.class_field_combo.addItem("(none)", None)
        attr_layout.addWidget(self.class_field_combo)
        attr_layout.addWidget(QLabel("Class value"))
        self.class_value_edit = QLineEdit()
        self.class_value_edit.setPlaceholderText("e.g. Vegetation, Soil, Built-up")
        attr_layout.addWidget(self.class_value_edit)
        layout.addWidget(attr_group)

        # Navigation -----------------------------------------------------
        nav_group = QGroupBox("Current target polygon")
        nav_layout = QVBoxLayout(nav_group)

        self.progress_label = QLabel("Object: — / —")
        self.progress_label.setAlignment(Qt.AlignCenter)
        font = self.progress_label.font()
        font.setBold(True)
        font.setPointSize(font.pointSize() + 2)
        self.progress_label.setFont(font)
        nav_layout.addWidget(self.progress_label)

        self.fid_label = QLabel("Feature ID: —")
        self.fid_label.setAlignment(Qt.AlignCenter)
        nav_layout.addWidget(self.fid_label)

        row = QHBoxLayout()
        self.previous_button = QPushButton("◀ Previous")
        self.next_button = QPushButton("Next ▶")
        self.previous_button.clicked.connect(self.previous_feature)
        self.next_button.clicked.connect(self.next_feature)
        row.addWidget(self.previous_button)
        row.addWidget(self.next_button)
        nav_layout.addLayout(row)
        layout.addWidget(nav_group)

        # SAM ------------------------------------------------------------
        sam_group = QGroupBox("SAM-assisted digitization")
        sam_layout = QVBoxLayout(sam_group)

        self.sam_status_label = QLabel(
            "Geo-SAM status: not connected. Geo-SAM must be installed and enabled."
        )
        self.sam_status_label.setWordWrap(True)
        sam_layout.addWidget(self.sam_status_label)

        self.clip_sam_checkbox = QCheckBox("Clip accepted SAM polygon to current target box")
        self.clip_sam_checkbox.setChecked(True)
        sam_layout.addWidget(self.clip_sam_checkbox)

        self.keep_largest_checkbox = QCheckBox("Keep largest SAM component")
        self.keep_largest_checkbox.setChecked(True)
        self.keep_largest_checkbox.setToolTip(
            "Uses Geo-SAM's Max Polygon Only mode to suppress disconnected mask fragments."
        )
        sam_layout.addWidget(self.keep_largest_checkbox)

        self.sam_button = QPushButton("✦ SAM Select")
        self.sam_button.setToolTip(
            "Open/configure Geo-SAM for the selected raster, then activate a foreground-point prompt."
        )
        self.sam_button.clicked.connect(self.start_sam_select)
        sam_layout.addWidget(self.sam_button)

        accept_row = QHBoxLayout()
        self.accept_sam_button = QPushButton("✓ Accept SAM")
        self.accept_sam_button.setToolTip(
            "Copy the current Geo-SAM prompt polygon into the selected annotation layer."
        )
        self.accept_sam_button.clicked.connect(self.accept_sam_result)
        accept_row.addWidget(self.accept_sam_button)

        self.accept_next_button = QPushButton("✓ Accept + Next ▶")
        self.accept_next_button.clicked.connect(self.accept_sam_and_next)
        accept_row.addWidget(self.accept_next_button)
        sam_layout.addLayout(accept_row)

        self.clear_sam_button = QPushButton("Clear SAM preview")
        self.clear_sam_button.clicked.connect(self.clear_sam_preview)
        sam_layout.addWidget(self.clear_sam_button)
        layout.addWidget(sam_group)

        # Manual digitizing ---------------------------------------------
        tools_group = QGroupBox("Manual digitizing")
        tools_layout = QVBoxLayout(tools_group)

        self.digitize_button = QPushButton("✏ Digitize polygon")
        self.digitize_button.setToolTip(
            "Make the annotation layer active, start editing if needed, and activate Add Feature."
        )
        self.digitize_button.clicked.connect(self.start_digitizing)
        tools_layout.addWidget(self.digitize_button)

        self.vertex_button = QPushButton("🔧 Edit vertices")
        self.vertex_button.setToolTip(
            "Make the annotation layer active and activate QGIS's vertex editing tool."
        )
        self.vertex_button.clicked.connect(self.edit_vertices)
        tools_layout.addWidget(self.vertex_button)

        self.save_button = QPushButton("💾 Save edits")
        self.save_button.clicked.connect(self.save_edits)
        tools_layout.addWidget(self.save_button)

        layout.addWidget(tools_group)
        layout.addStretch(1)

        self.nav_combo.layerChanged.connect(self._navigation_layer_changed)
        self.edit_combo.layerChanged.connect(self._edit_layer_changed)

        self.previous_button.setEnabled(False)
        self.next_button.setEnabled(False)

        self.dock.setWidget(root)
        self.iface.addDockWidget(Qt.RightDockWidgetArea, self.dock)

        self._navigation_layer_changed(self.nav_combo.currentLayer())
        self._edit_layer_changed(self.edit_combo.currentLayer())
        self.dock.hide()

    def show_dock(self):
        if self.dock is None:
            self._create_dock()
        self.dock.show()
        self.dock.raise_()

    # ------------------------------------------------------------------
    # Layer handling
    # ------------------------------------------------------------------
    def _navigation_layer_changed(self, layer):
        self.nav_layer = layer if isinstance(layer, QgsVectorLayer) else None
        self.reload_navigation()

    def _edit_layer_changed(self, layer):
        self.edit_layer = layer if isinstance(layer, QgsVectorLayer) else None
        self._refresh_class_fields()

    def _refresh_class_fields(self):
        if self.class_field_combo is None:
            return
        previous_name = self.class_field_combo.currentText()
        self.class_field_combo.blockSignals(True)
        self.class_field_combo.clear()
        self.class_field_combo.addItem("(none)", None)
        layer = self.edit_combo.currentLayer() if self.edit_combo is not None else None
        if isinstance(layer, QgsVectorLayer):
            for field in layer.fields():
                self.class_field_combo.addItem(field.name(), field.name())
        previous_index = self.class_field_combo.findText(previous_name)
        if previous_index >= 0:
            self.class_field_combo.setCurrentIndex(previous_index)
        self.class_field_combo.blockSignals(False)

    def _is_polygon_layer(self, layer):
        return (
            isinstance(layer, QgsVectorLayer)
            and QgsWkbTypes.geometryType(layer.wkbType()) == QgsWkbTypes.PolygonGeometry
        )

    def reload_navigation(self):
        layer = self.nav_combo.currentLayer() if self.nav_combo is not None else None

        if not self._is_polygon_layer(layer):
            self.nav_layer = None
            self.feature_ids = []
            self.current_index = -1
            self._update_progress()
            return

        self.nav_layer = layer
        self.feature_ids = sorted(feature.id() for feature in layer.getFeatures())

        if not self.feature_ids:
            self.current_index = -1
            self._update_progress()
            self.iface.messageBar().pushWarning(
                "Guided Digitizer", "The navigation layer contains no polygons."
            )
            return

        saved_fid = self._saved_feature_id()
        if saved_fid in self.feature_ids:
            self.current_index = self.feature_ids.index(saved_fid)
        elif self.current_index < 0 or self.current_index >= len(self.feature_ids):
            self.current_index = 0

        self.go_to_current_feature()

    # ------------------------------------------------------------------
    # Navigation
    # ------------------------------------------------------------------
    def previous_feature(self):
        if not self.feature_ids:
            return
        if self.current_index > 0:
            self.clear_sam_preview(silent=True)
            self.current_index -= 1
            self.go_to_current_feature()

    def next_feature(self):
        if not self.feature_ids:
            return
        if self.current_index < len(self.feature_ids) - 1:
            self.clear_sam_preview(silent=True)
            self.current_index += 1
            self.go_to_current_feature()

    def go_to_current_feature(self):
        if (
            self.nav_layer is None
            or not self.feature_ids
            or self.current_index < 0
            or self.current_index >= len(self.feature_ids)
        ):
            self._update_progress()
            return

        fid = self.feature_ids[self.current_index]
        feature = self.nav_layer.getFeature(fid)
        if not feature.isValid() or feature.geometry().isEmpty():
            self.iface.messageBar().pushWarning(
                "Guided Digitizer", f"Navigation feature {fid} has no usable geometry."
            )
            return

        self.nav_layer.selectByIds([fid])

        extent = feature.geometry().boundingBox()
        destination_crs = self.canvas.mapSettings().destinationCrs()
        if self.nav_layer.crs().isValid() and destination_crs.isValid():
            if self.nav_layer.crs() != destination_crs:
                transform = QgsCoordinateTransform(
                    self.nav_layer.crs(), destination_crs, QgsProject.instance()
                )
                extent = transform.transformBoundingBox(extent)

        extent.scale(1.20)
        self.canvas.setExtent(extent)
        self.canvas.refresh()

        self._save_feature_id(fid)
        self._update_progress()

    def _update_progress(self):
        total = len(self.feature_ids)
        if total and 0 <= self.current_index < total:
            fid = self.feature_ids[self.current_index]
            self.progress_label.setText(f"Object: {self.current_index + 1} / {total}")
            self.fid_label.setText(f"Feature ID: {fid}")
            self.previous_button.setEnabled(self.current_index > 0)
            self.next_button.setEnabled(self.current_index < total - 1)
        else:
            self.progress_label.setText("Object: — / —")
            self.fid_label.setText("Feature ID: —")
            self.previous_button.setEnabled(False)
            self.next_button.setEnabled(False)

    def _current_navigation_geometry(self, target_crs=None):
        if (
            self.nav_layer is None
            or not self.feature_ids
            or self.current_index < 0
            or self.current_index >= len(self.feature_ids)
        ):
            return None

        feature = self.nav_layer.getFeature(self.feature_ids[self.current_index])
        if not feature.isValid() or feature.geometry().isEmpty():
            return None

        geometry = QgsGeometry(feature.geometry())
        if (
            target_crs is not None
            and self.nav_layer.crs().isValid()
            and target_crs.isValid()
            and self.nav_layer.crs() != target_crs
        ):
            geometry.transform(
                QgsCoordinateTransform(
                    self.nav_layer.crs(), target_crs, QgsProject.instance()
                )
            )
        return geometry

    # ------------------------------------------------------------------
    # Geo-SAM integration
    # ------------------------------------------------------------------
    def _find_geosam_plugin(self):
        try:
            from qgis import utils as qgis_utils
        except Exception:
            return None

        for plugin in qgis_utils.plugins.values():
            if hasattr(plugin, "actionSamTool") and hasattr(plugin, "create_widget_selector"):
                return plugin
        return None

    def _find_geosam_selector(self):
        plugin = self._find_geosam_plugin()
        if plugin is None:
            return None
        return getattr(plugin, "wdg_select", None)

    def _find_geosam_dock(self):
        dock = self.iface.mainWindow().findChild(QDockWidget, "GeoSAM")
        if dock is not None:
            return dock
        for candidate in self.iface.mainWindow().findChildren(QDockWidget):
            title = (candidate.windowTitle() or "").lower()
            if "geo-sam" in title or "geosam" in title:
                return candidate
        return None

    def start_sam_select(self):
        raster_layer = self.raster_combo.currentLayer() if self.raster_combo else None
        if raster_layer is None:
            QMessageBox.warning(
                self.iface.mainWindow(),
                "Guided Digitizer",
                "Choose the aerial imagery/raster layer first.",
            )
            return

        if self._target_layer() is None:
            return
        if self._current_navigation_geometry() is None:
            QMessageBox.warning(
                self.iface.mainWindow(),
                "Guided Digitizer",
                "Choose and load a navigation polygon layer first.",
            )
            return

        plugin = self._find_geosam_plugin()
        if plugin is not None:
            try:
                plugin.create_widget_selector()
            except Exception as exc:
                QMessageBox.warning(
                    self.iface.mainWindow(),
                    "Guided Digitizer",
                    "Geo-SAM could not be opened.\n\n" + str(exc),
                )
                return
        else:
            action = self.iface.mainWindow().findChild(QAction, "mActionGeoSamTool")
            if action is None:
                QMessageBox.warning(
                    self.iface.mainWindow(),
                    "Guided Digitizer",
                    "Geo-SAM was not found. Install and enable the official 'Geo SAM' "
                    "plugin in QGIS, configure its dependencies/model once, then try again.",
                )
                self.sam_status_label.setText("Geo-SAM status: plugin not found.")
                return
            action.trigger()

        self.sam_status_label.setText("Geo-SAM status: opening / configuring…")
        QTimer.singleShot(250, self._configure_geosam_for_guided_digitizing)

    def _configure_geosam_for_guided_digitizing(self):
        raster_layer = self.raster_combo.currentLayer() if self.raster_combo else None
        if raster_layer is None:
            return

        selector = self._find_geosam_selector()
        dock = self._find_geosam_dock()

        # Prefer the Selector Python object because it is less ambiguous than
        # searching the UI tree, but support the UI tree as a fallback.
        widget = getattr(selector, "wdg_sel", None) if selector is not None else dock
        if widget is None:
            self.sam_status_label.setText(
                "Geo-SAM status: opened, but its segmentation panel was not found."
            )
            return

        try:
            source_mode = widget.findChild(QComboBox, "SourceModeComboBox")
            if source_mode is not None and source_mode.count() > 0:
                source_mode.setCurrentIndex(0)  # Live Encoding

            live_combo = widget.findChild(QgsMapLayerComboBox, "LiveEncodingLayerComboBox")
            if live_combo is not None:
                live_combo.setLayer(raster_layer)

            max_only = widget.findChild(QRadioButton, "radioButton_max_object_mode")
            if max_only is not None:
                max_only.setChecked(self.keep_largest_checkbox.isChecked())

            # A live-encoding source may initialize its map tools through the
            # layerChanged signal. Give that signal a moment, then activate FG.
            QTimer.singleShot(150, self._activate_geosam_foreground_prompt)
            self.sam_status_label.setText(
                "Geo-SAM status: ready. Click an object in the current box; "
                "then use Accept SAM."
            )
        except Exception as exc:
            self.sam_status_label.setText("Geo-SAM status: configuration failed.")
            QMessageBox.warning(
                self.iface.mainWindow(),
                "Guided Digitizer",
                "Geo-SAM opened, but Guided Digitizer could not configure it automatically.\n\n"
                + str(exc),
            )

    def _activate_geosam_foreground_prompt(self):
        selector = self._find_geosam_selector()
        if selector is not None and hasattr(selector, "draw_foreground_point"):
            try:
                selector.draw_foreground_point()
                return
            except Exception:
                pass

        dock = self._find_geosam_dock()
        if dock is not None:
            button = dock.findChild(QPushButton, "pushButton_fg")
            if button is not None:
                button.click()

    def _sam_prompt_geometries(self):
        selector = self._find_geosam_selector()
        if selector is None or not hasattr(selector, "polygon"):
            return [], None

        polygon = selector.polygon
        layer = polygon.get_layer() if hasattr(polygon, "get_layer") else None
        source_crs = layer.crs() if layer is not None else None

        prompt_canvas = getattr(polygon, "canvas_prompt_polygon", None)
        geometries = list(getattr(prompt_canvas, "geometry_list", []) or [])

        # Fallback to preview geometries if a Geo-SAM version exposes the mask
        # there but not in the prompt overlay.
        if not geometries:
            preview_canvas = getattr(polygon, "canvas_preview_polygon", None)
            geometries = list(getattr(preview_canvas, "geometry_list", []) or [])

        return [QgsGeometry(g) for g in geometries], source_crs

    def _polygon_only_geometry(self, geometry):
        if geometry is None or geometry.isEmpty():
            return None

        try:
            if not geometry.isGeosValid():
                geometry = geometry.makeValid()
        except Exception:
            pass

        if geometry is None or geometry.isEmpty():
            return None

        if QgsWkbTypes.geometryType(geometry.wkbType()) == QgsWkbTypes.PolygonGeometry:
            return geometry

        # makeValid/intersection can occasionally return a GeometryCollection.
        # Retain only polygonal members and union them back together.
        try:
            polygon_parts = [
                part
                for part in geometry.asGeometryCollection()
                if QgsWkbTypes.geometryType(part.wkbType())
                == QgsWkbTypes.PolygonGeometry
                and not part.isEmpty()
            ]
            if not polygon_parts:
                return None
            merged = QgsGeometry.unaryUnion(polygon_parts)
            if merged is not None and not merged.isEmpty():
                return merged
        except Exception:
            return None
        return None

    def accept_sam_result(self):
        layer = self._prepare_target_for_editing()
        if layer is None:
            return False

        sam_geometries, sam_crs = self._sam_prompt_geometries()
        if not sam_geometries:
            QMessageBox.information(
                self.iface.mainWindow(),
                "Guided Digitizer",
                "No current SAM polygon was found. Click SAM Select, click an object, "
                "and wait for the segmentation preview before accepting it.",
            )
            return False

        target_crs = layer.crs()
        target_box = self._current_navigation_geometry(target_crs=target_crs)
        if self.clip_sam_checkbox.isChecked() and target_box is None:
            QMessageBox.warning(
                self.iface.mainWindow(),
                "Guided Digitizer",
                "The current target box could not be read, so the SAM result was not added.",
            )
            return False

        added = 0
        for sam_geometry in sam_geometries:
            geometry = QgsGeometry(sam_geometry)
            if (
                sam_crs is not None
                and sam_crs.isValid()
                and target_crs.isValid()
                and sam_crs != target_crs
            ):
                try:
                    geometry.transform(
                        QgsCoordinateTransform(sam_crs, target_crs, QgsProject.instance())
                    )
                except Exception as exc:
                    QMessageBox.warning(
                        self.iface.mainWindow(),
                        "Guided Digitizer",
                        "Could not transform the SAM polygon to the annotation CRS.\n\n"
                        + str(exc),
                    )
                    return False

            if self.clip_sam_checkbox.isChecked():
                try:
                    geometry = geometry.intersection(target_box)
                except Exception as exc:
                    QMessageBox.warning(
                        self.iface.mainWindow(),
                        "Guided Digitizer",
                        "Could not clip the SAM polygon to the current target box.\n\n"
                        + str(exc),
                    )
                    return False

            geometry = self._polygon_only_geometry(geometry)
            if geometry is None or geometry.isEmpty():
                continue

            feature = QgsFeature(layer.fields())
            feature.setGeometry(geometry)

            class_field = self.class_field_combo.currentData()
            class_value = self.class_value_edit.text().strip()
            if class_field and class_value:
                field_index = layer.fields().indexFromName(class_field)
                if field_index >= 0:
                    field = layer.fields().at(field_index)
                    converted_value = class_value
                    # QVariant conversion differs slightly across QGIS/PyQt
                    # versions, so fall back to the entered string on failure.
                    try:
                        converted_value = field.convertCompatible(class_value)
                        if isinstance(converted_value, tuple):
                            converted_value = converted_value[0]
                    except Exception:
                        converted_value = class_value
                    feature.setAttribute(field_index, converted_value)

            if layer.addFeature(feature):
                added += 1

        if added == 0:
            self.iface.messageBar().pushWarning(
                "Guided Digitizer",
                "The SAM result did not contain a polygon inside the current target box.",
            )
            return False

        layer.updateExtents()
        layer.triggerRepaint()
        self.iface.setActiveLayer(layer)
        self.canvas.refresh()

        self.iface.messageBar().pushSuccess(
            "Guided Digitizer",
            f"Added {added} SAM polygon{'s' if added != 1 else ''} to {layer.name()}.",
        )
        self.sam_status_label.setText(
            f"Geo-SAM status: accepted {added} polygon{'s' if added != 1 else ''}. "
            "Ready for the next click."
        )

        self.clear_sam_preview(silent=True)
        QTimer.singleShot(50, self._activate_geosam_foreground_prompt)
        return True

    def accept_sam_and_next(self):
        if self.accept_sam_result():
            self.next_feature()
            QTimer.singleShot(80, self._activate_geosam_foreground_prompt)

    def clear_sam_preview(self, silent=False):
        selector = self._find_geosam_selector()
        if selector is not None:
            try:
                selector.clear_layers(clear_extent=False)
                if not silent:
                    self.sam_status_label.setText("Geo-SAM status: preview cleared.")
                return
            except Exception:
                pass

        if not silent:
            self.sam_status_label.setText(
                "Geo-SAM status: no connected preview was available to clear."
            )

    # ------------------------------------------------------------------
    # Manual digitization controls
    # ------------------------------------------------------------------
    def _target_layer(self):
        layer = self.edit_combo.currentLayer() if self.edit_combo is not None else None
        if not self._is_polygon_layer(layer):
            QMessageBox.warning(
                self.iface.mainWindow(),
                "Guided Digitizer",
                "Choose a polygon digitization layer first.",
            )
            return None
        self.edit_layer = layer
        return layer

    def _prepare_target_for_editing(self):
        layer = self._target_layer()
        if layer is None:
            return None

        self.iface.setActiveLayer(layer)

        if not layer.isEditable():
            if not layer.startEditing():
                QMessageBox.warning(
                    self.iface.mainWindow(),
                    "Guided Digitizer",
                    "QGIS could not start editing on the selected digitization layer.",
                )
                return None

        return layer

    def start_digitizing(self):
        layer = self._prepare_target_for_editing()
        if layer is None:
            return

        self.iface.actionAddFeature().trigger()
        self.iface.messageBar().pushInfo(
            "Guided Digitizer", "Digitize the polygon in the current box."
        )

    def edit_vertices(self):
        layer = self._prepare_target_for_editing()
        if layer is None:
            return

        if hasattr(self.iface, "actionVertexToolActiveLayer"):
            self.iface.actionVertexToolActiveLayer().trigger()
        else:
            self.iface.actionVertexTool().trigger()

    def save_edits(self):
        layer = self._target_layer()
        if layer is None:
            return

        self.iface.setActiveLayer(layer)

        if not layer.isEditable():
            self.iface.messageBar().pushInfo(
                "Guided Digitizer", "There are no active edits to save."
            )
            return

        self.iface.actionSaveActiveLayerEdits().trigger()
        self.iface.messageBar().pushSuccess("Guided Digitizer", "Edits saved.")

    # ------------------------------------------------------------------
    # Remember current location
    # ------------------------------------------------------------------
    def _settings_key(self):
        if self.nav_layer is None:
            return None
        project_name = QgsProject.instance().fileName() or "unsaved_project"
        return f"{self.SETTINGS_ROOT}/{project_name}/{self.nav_layer.id()}/last_fid"

    def _save_feature_id(self, fid):
        key = self._settings_key()
        if key:
            QgsSettings().setValue(key, int(fid))

    def _saved_feature_id(self):
        key = self._settings_key()
        if not key:
            return None
        value = QgsSettings().value(key, None)
        if value is None:
            return None
        try:
            return int(value)
        except (TypeError, ValueError):
            return None
